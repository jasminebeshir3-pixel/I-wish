package org.example.person4;

import javax.swing.*;
import java.awt.*;

public class FriendWishlistPanel extends JPanel {

    private final DefaultListModel<String> wishlistModel = new DefaultListModel<>();
    private final JList<String> wishlistList = new JList<>(wishlistModel);
    private final JLabel titleLabel;

    public FriendWishlistPanel(String friendName) {

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title
        titleLabel = new JLabel(
                friendName + "'s Wishlist",
                SwingConstants.CENTER
        );

        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, BorderLayout.NORTH);

        // Wishlist list
        wishlistList.setFont(new Font("Arial", Font.PLAIN, 15));
        wishlistList.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        add(new JScrollPane(wishlistList), BorderLayout.CENTER);

        // Double click on item -> open details
        wishlistList.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseClicked(
                            java.awt.event.MouseEvent e) {

                        if (e.getClickCount() == 2) {

                            String selected =
                                    wishlistList.getSelectedValue();

                            if (selected != null
                                    && !selected.startsWith("No ")) {

                                new WishlistItemDetailsGUI(selected);
                            }
                        }
                    }
                }
        );
    }

    // Change friend's name
    public void setFriendName(String name) {

        titleLabel.setText(
                name + "'s Wishlist"
        );
    }

    // Add item to wishlist
    public void addWishlistItem(String item) {

        wishlistModel.addElement(item);
    }

    // Clear wishlist
    public void clearWishlist() {

        wishlistModel.clear();
    }
}
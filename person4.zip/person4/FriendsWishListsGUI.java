package org.example.person4;

import javax.swing.*;
import java.awt.*;

public class FriendsWishListsGUI extends JFrame {

    // Friends list
    private final DefaultListModel<String> friendsModel =
            new DefaultListModel<>();

    private final JList<String> friendsList =
            new JList<>(friendsModel);

    // Wishlist panel
    private final FriendWishlistPanel wishlistPanel;


    public FriendsWishListsGUI() {

        // -----------------------------
        // Window settings
        // -----------------------------

        setTitle("Friends' Wish Lists");

        setSize(900, 600);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);


        // -----------------------------
        // LEFT SIDE - Friends
        // -----------------------------

        JPanel leftPanel =
                new JPanel(new BorderLayout(10, 10));

        leftPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        leftPanel.setPreferredSize(
                new Dimension(280, 0)
        );


        // Friends title
        JLabel friendsTitle =
                new JLabel(
                        "My Friends",
                        SwingConstants.CENTER
                );

        friendsTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        leftPanel.add(
                friendsTitle,
                BorderLayout.NORTH
        );


        // Friends list
        friendsList.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        friendsList.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        leftPanel.add(
                new JScrollPane(friendsList),
                BorderLayout.CENTER
        );


        // Refresh button
        JButton refreshBtn =
                new JButton("Refresh Friends");

        leftPanel.add(
                refreshBtn,
                BorderLayout.SOUTH
        );


        // -----------------------------
        // RIGHT SIDE - Wishlist
        // -----------------------------

        wishlistPanel =
                new FriendWishlistPanel(
                        "Select a friend"
                );


        // -----------------------------
        // Split screen
        // -----------------------------

        JSplitPane splitPane =
                new JSplitPane(
                        JSplitPane.HORIZONTAL_SPLIT,
                        leftPanel,
                        wishlistPanel
                );

        splitPane.setDividerLocation(280);

        setContentPane(splitPane);


        // -----------------------------
        // Events
        // -----------------------------

        // Refresh friends
        refreshBtn.addActionListener(
                e -> loadFriends()
        );


        // Select friend
        friendsList.addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {

                String selected =
                        friendsList.getSelectedValue();

                if (selected != null
                        && !selected.startsWith("No ")) {

                    loadFriendWishlist(selected);
                }
            }
        });


        // -----------------------------
        // Load test friends
        // -----------------------------

        loadFriends();
    }


    // =========================================================
    // Load Friends
    // =========================================================

    private void loadFriends() {

        friendsModel.clear();


        // TEST DATA
        // -----------------------------
        // Later Person 6 can replace
        // this part with server data.
        // -----------------------------

        friendsModel.addElement(
                "Ahmed (ID: 2)"
        );

        friendsModel.addElement(
                "Sara (ID: 3)"
        );

        friendsModel.addElement(
                "Mariam (ID: 4)"
        );
    }


    // =========================================================
    // Load Friend Wishlist
    // =========================================================

    private void loadFriendWishlist(
            String selectedFriend) {

        try {

            // -----------------------------------------
            // Get friend's name
            // Example:
            // "Ahmed (ID: 2)"
            // -----------------------------------------

            String friendName =
                    selectedFriend.substring(
                            0,
                            selectedFriend.indexOf(" (ID:")
                    ).trim();


            // Change title
            wishlistPanel.setFriendName(
                    friendName
            );


            // Clear old wishlist
            wishlistPanel.clearWishlist();


            // -----------------------------------------
            // TEST WISHLIST DATA
            // -----------------------------------------

            wishlistPanel.addWishlistItem(
                    "ID:101 | PlayStation 5 | Price:$500 | Raised:$250 | Done:false"
            );

            wishlistPanel.addWishlistItem(
                    "ID:102 | Headphones | Price:$100 | Raised:$100 | Done:true"
            );

            wishlistPanel.addWishlistItem(
                    "ID:103 | Smart Watch | Price:$200 | Raised:$50 | Done:false"
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading friend's wishlist: "
                            + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    // =========================================================
    // Main
    // =========================================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            FriendsWishListsGUI gui =
                    new FriendsWishListsGUI();

            gui.setVisible(true);
        });
    }
}
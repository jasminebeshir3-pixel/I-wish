package org.example.person4;

import javax.swing.*;
import java.awt.*;

public class WishlistItemDetailsGUI extends JFrame {

    public WishlistItemDetailsGUI(String rawItem) {

        // -----------------------------
        // Window settings
        // -----------------------------

        setTitle("Item Details");

        setSize(480, 350);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );


        // -----------------------------
        // Main panel
        // -----------------------------

        JPanel panel = new JPanel();

        panel.setLayout(
                new BoxLayout(
                        panel,
                        BoxLayout.Y_AXIS
                )
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        25, 25, 25, 25
                )
        );


        // -----------------------------
        // Title
        // -----------------------------

        JLabel title =
                new JLabel(
                        "Wishlist Item Details"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        title.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );


        // -----------------------------
        // Parse item
        // -----------------------------

        /*
         * Example:
         *
         * ID:101 | PlayStation 5 |
         * Price:$500 |
         * Raised:$250 |
         * Done:false
         */

        String[] parts =
                rawItem.split("\\|");


        JLabel idLabel =
                createLabel(
                        parts.length > 0
                                ? parts[0].trim()
                                : "N/A"
                );


        JLabel nameLabel =
                createLabel(
                        parts.length > 1
                                ? parts[1].trim()
                                : "N/A"
                );


        JLabel priceLabel =
                createLabel(
                        parts.length > 2
                                ? parts[2].trim()
                                : "N/A"
                );


        JLabel raisedLabel =
                createLabel(
                        parts.length > 3
                                ? parts[3].trim()
                                : "N/A"
                );


        JLabel doneLabel =
                createLabel(
                        parts.length > 4
                                ? parts[4].trim()
                                : "N/A"
                );


        // -----------------------------
        // Contribute button
        // -----------------------------

        JButton contributeBtn =
                new JButton("Contribute");

        contributeBtn.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );


        contributeBtn.addActionListener(e -> {

            /*
             * Person 5 will implement
             * the real contribution screen.
             *
             * For now we only show a message.
             */

            JOptionPane.showMessageDialog(
                    this,
                    "Contribution screen will be opened here.",
                    "Contribute",
                    JOptionPane.INFORMATION_MESSAGE
            );
        });


        // -----------------------------
        // Close button
        // -----------------------------

        JButton closeBtn =
                new JButton("Close");

        closeBtn.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        closeBtn.addActionListener(
                e -> dispose()
        );


        // -----------------------------
        // Add components
        // -----------------------------

        panel.add(title);

        panel.add(
                Box.createVerticalStrut(25)
        );

        panel.add(idLabel);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(nameLabel);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(priceLabel);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(raisedLabel);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(doneLabel);

        panel.add(
                Box.createVerticalStrut(25)
        );

        panel.add(contributeBtn);

        panel.add(
                Box.createVerticalStrut(10)
        );

        panel.add(closeBtn);


        // Add panel to frame
        add(panel);

        setVisible(true);
    }


    // =========================================================
    // Create Label
    // =========================================================

    private JLabel createLabel(String text) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        16
                )
        );

        label.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        return label;
    }
}
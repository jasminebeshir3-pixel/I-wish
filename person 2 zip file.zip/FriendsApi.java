package org.example.person2;


import java.util.List;

/**
 * Everything the Friends screens can ask for. The GUI only talks to this interface,
 * so it works the same with the real server ({@link RemoteFriendsApi}) or with fake
 * in-memory data ({@link MockFriendsApi}) - handy while the server isn't ready yet.
 *
 * All methods may block on the network: never call them on the Swing event thread
 * (FriendsPanel already uses SwingWorker for that).
 * Action methods return a friendly message to show to the user.
 */
public interface FriendsApi {

    List<FriendDTO> getFriends(int userId) throws FriendsException;

    List<FriendRequestDTO> getReceivedRequests(int userId) throws FriendsException;

    List<FriendRequestDTO> getSentRequests(int userId) throws FriendsException;

    String sendRequest(int userId, String usernameOrEmail) throws FriendsException;

    String acceptRequest(int userId, int requestId) throws FriendsException;

    String declineRequest(int userId, int requestId) throws FriendsException;

    String cancelRequest(int userId, int requestId) throws FriendsException;

    String removeFriend(int userId, int friendId) throws FriendsException;
}

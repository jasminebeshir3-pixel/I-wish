package org.example.person2;

import org.example.net.ServerClient;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Talks to Person 6's real server instead of the fake DevServer that came with
 * this screen. Implements the same FriendsApi interface FriendsPanel already
 * expects, so nothing in FriendsPanel/Ui/DTOs had to change.
 *
 * Note: ADD_FRIEND on the real server only looks people up by username (not
 * email), so "sendRequest" only works if the text typed is a username.
 */
public class RealFriendsApi implements FriendsApi {

    @Override
    public List<FriendDTO> getFriends(int userId) throws FriendsException {
        String response = ServerClient.send("GET_FRIENDS|" + userId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }

        List<FriendDTO> result = new ArrayList<>();
        for (String[] row : ServerClient.parseRows(ServerClient.dataOf(response))) {
            int id = Integer.parseInt(row[0]);
            String username = row[1];
            String email = row.length > 2 ? row[2] : "";
            result.add(new FriendDTO(id, username, email));
        }
        return result;
    }

    @Override
    public List<FriendRequestDTO> getReceivedRequests(int userId) throws FriendsException {
        String response = ServerClient.send("GET_FRIEND_REQUESTS|" + userId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return parseRequests(ServerClient.dataOf(response));
    }

    @Override
    public List<FriendRequestDTO> getSentRequests(int userId) throws FriendsException {
        String response = ServerClient.send("GET_SENT_FRIEND_REQUESTS|" + userId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return parseRequests(ServerClient.dataOf(response));
    }

    @Override
    public String sendRequest(int userId, String usernameOrEmail) throws FriendsException {
        String response = ServerClient.send("ADD_FRIEND|" + userId + "|" + usernameOrEmail);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return "Friend request sent to " + usernameOrEmail + ".";
    }

    @Override
    public String acceptRequest(int userId, int requestId) throws FriendsException {
        String response = ServerClient.send("ACCEPT_FRIEND|" + requestId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return "Friend request accepted.";
    }

    @Override
    public String declineRequest(int userId, int requestId) throws FriendsException {
        String response = ServerClient.send("DECLINE_FRIEND|" + requestId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return "Friend request declined.";
    }

    @Override
    public String cancelRequest(int userId, int requestId) throws FriendsException {
        String response = ServerClient.send("CANCEL_FRIEND_REQUEST|" + requestId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return "Friend request cancelled.";
    }

    @Override
    public String removeFriend(int userId, int friendId) throws FriendsException {
        String response = ServerClient.send("REMOVE_FRIEND|" + userId + "|" + friendId);
        if (!ServerClient.isOk(response)) {
            throw new FriendsException(ServerClient.dataOf(response));
        }
        return "Friend removed.";
    }

    // ==========================================
    // Shared parsing for received/sent requests
    // ==========================================

    private List<FriendRequestDTO> parseRequests(String data) {
        List<FriendRequestDTO> result = new ArrayList<>();
        for (String[] row : ServerClient.parseRows(data)) {
            int requestId = Integer.parseInt(row[0]);
            String username = row[1];
            String email = row.length > 2 ? row[2] : "";

            LocalDateTime createdAt;
            try {
                createdAt = row.length > 3 ? LocalDateTime.parse(row[3]) : LocalDateTime.now();
            } catch (Exception e) {
                createdAt = LocalDateTime.now();
            }

            // The server doesn't return the other person's user id for this list -
            // FriendsPanel only ever needs requestId to act on a request, so 0 is a safe placeholder.
            result.add(new FriendRequestDTO(requestId, 0, username, email, createdAt));
        }
        return result;
    }
}

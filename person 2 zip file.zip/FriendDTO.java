package org.example.person2;

import java.io.Serializable;

/** A user as seen in a friends list (or a search result). */
public class FriendDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private final int id;
    private final String username;
    private final String email;

    public FriendDTO(int id, String username, String email) {
        this.id = id;
        this.username = username;
        this.email = email;
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return username;
    }
}

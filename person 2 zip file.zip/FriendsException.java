package org.example.person2;

/**
 * A problem in the Friends feature whose message is safe and friendly enough
 * to show directly to the user (e.g. "You are already friends with Sara.").
 */
public class FriendsException extends Exception {

    private static final long serialVersionUID = 1L;

    public FriendsException(String message) {
        super(message);
    }

    public FriendsException(String message, Throwable cause) {
        super(message, cause);
    }
}

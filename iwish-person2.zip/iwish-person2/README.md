# I-Wish — Person 2 (Friends System)

This is your Friends screen, fully wired to the real server. Drop this whole
folder's contents into your IntelliJ project (or open it as its own Maven
project) — it's self-contained and will compile and run on its own.

## What's yours
- **`FriendsPanel.java`** + **`Ui.java`** — your screen, untouched. Same 3 tabs
  (My Friends / Requests / Add Friend), same design.
- **`FriendsApi.java`** — the interface your screen talks to (unchanged).
- **`RealFriendsApi.java`** — NEW. Replaces your old `RemoteFriendsApi` +
  `DevServer` + `Request`/`Response` setup. Talks to the real team server using
  plain-text commands instead of Java object serialization.
- **`FriendDTO.java`**, **`FriendRequestDTO.java`**, **`FriendsException.java`**
  — unchanged, just moved into the `org.example` package (the whole team's
  shared package) instead of `com.iwish.common`.
- **`FriendsDemoApp.java`** — run this to see your screen live.

## What's shared with the rest of the team (Person 6's files)
- `net/ServerClient.java`, `net/Session.java` — the connection helper every
  screen uses.
- `Protocol.java` — command list. Two commands were added for your "sent
  requests" and "cancel request" features: `GET_SENT_FRIEND_REQUESTS` and
  `CANCEL_FRIEND_REQUEST`.
- `DatabaseManager.java`, `ClientHandler.java`, `Server.java` — the real
  server. Included here so you can run and test against it on your own
  machine. **When the team merges everyone's code, use whichever copy of
  these three files is the newest/most complete** — they should be identical
  copies for everyone.
- `TestClient.java` — lets you type raw commands to the server to debug.

## How to run it
1. Run `sql/schema.sql` in MySQL Workbench (creates the database + tables +
   sample catalog items).
2. Open `DatabaseManager.java` and set `DB_USER` / `DB_PASS` to your MySQL
   login.
3. Run `Server.java` — wait for `[Server] Started on port 5000`.
4. Run `FriendsDemoApp.java` — your Friends screen opens, showing real data
   for whichever user id `Session.currentUserId` is set to (default: `1`).

To see actual friends/requests, register a couple of test users first via
`TestClient.java`:
```
REGISTER|alice|1234|alice@mail.com
REGISTER|bob|1234|bob@mail.com
```
Then set `Session.currentUserId` to one of the ids you got back, and use the
"Add Friend" tab in your screen to send a request to the other by username.

## One limitation to know about
`ADD_FRIEND` on the real server only looks people up by **username**, not
email — so typing an email in "Add Friend" will show "User not found." If you
want email lookup too, that's a small addition Person 6 would need to make to
`DatabaseManager.findUserIdByUsername`.

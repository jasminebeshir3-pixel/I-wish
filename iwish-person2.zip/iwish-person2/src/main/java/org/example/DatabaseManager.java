package org.example;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {

    private static final String URL = "jdbc:mysql://localhost:3306/iwish_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "ParentWise123";
    private Connection connection;

    public DatabaseManager() {
        connect();
    }

    // Connection
    public void connect() {
        try {
            connection = DriverManager.getConnection(URL, DB_USER, DB_PASS);
            System.out.println("[DB] Connected successfully.");
        } catch (SQLException e) {
            System.err.println("[DB] Connection failed: " + e.getMessage());
        }
    }

    public void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) {
            System.err.println("[DB] Error closing connection: " + e.getMessage());
        }
    }
    // Person 1: Authentication
    public int registerUser(String username, String password, String email) throws SQLException {
        String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, username);
            ps.setString(2, password); // NOTE: hash this in a real app
            ps.setString(3, email);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    //Returns the user id if credentials match, or -1 if invalid.
    public int login(String username, String password) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        }
        return -1;
    }

    public Integer findUserIdByUsername(String username) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        }
        return null;
    }

    // Person 2: Friends system
    public void sendFriendRequest(int userId, int friendId) throws SQLException {
        String sql = "INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, 'PENDING')";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, friendId);
            ps.executeUpdate();
        }
    }

    public void respondToFriendRequest(int requestId, boolean accept) throws SQLException {
        String sql = "UPDATE friends SET status = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, accept ? "ACCEPTED" : "DECLINED");
            ps.setInt(2, requestId);
            ps.executeUpdate();
        }
    }

    public void removeFriend(int userId, int friendId) throws SQLException {
        String sql = "DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, friendId);
            ps.setInt(3, friendId);
            ps.setInt(4, userId);
            ps.executeUpdate();
        }
    }

    /** Returns rows: requestId,,senderUsername,,senderEmail,,createdAt */
    public List<String> getPendingFriendRequests(int userId) throws SQLException {
        List<String> results = new ArrayList<>();
        String sql = "SELECT f.id, u.username, u.email, f.created_at FROM friends f " +
                "JOIN users u ON f.user_id = u.id " +
                "WHERE f.friend_id = ? AND f.status = 'PENDING'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(rs.getInt("id") + Protocol.FIELD_SEP + rs.getString("username")
                            + Protocol.FIELD_SEP + rs.getString("email")
                            + Protocol.FIELD_SEP + rs.getTimestamp("created_at").toLocalDateTime());
                }
            }
        }
        return results;
    }

    /** Returns rows: requestId,,receiverUsername,,receiverEmail,,createdAt (requests this user sent, still pending) */
    public List<String> getSentFriendRequests(int userId) throws SQLException {
        List<String> results = new ArrayList<>();
        String sql = "SELECT f.id, u.username, u.email, f.created_at FROM friends f " +
                "JOIN users u ON f.friend_id = u.id " +
                "WHERE f.user_id = ? AND f.status = 'PENDING'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(rs.getInt("id") + Protocol.FIELD_SEP + rs.getString("username")
                            + Protocol.FIELD_SEP + rs.getString("email")
                            + Protocol.FIELD_SEP + rs.getTimestamp("created_at").toLocalDateTime());
                }
            }
        }
        return results;
    }

    /** Cancels a request the current user sent (only while it's still pending). */
    public void cancelFriendRequest(int requestId) throws SQLException {
        String sql = "DELETE FROM friends WHERE id = ? AND status = 'PENDING'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, requestId);
            ps.executeUpdate();
        }
    }

    /** Returns rows: friendId,,username,,email (accepted friends only, either direction) */
    public List<String> getFriends(int userId) throws SQLException {
        List<String> results = new ArrayList<>();
        String sql = "SELECT u.id, u.username, u.email FROM friends f " +
                "JOIN users u ON u.id = CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END " +
                "WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status = 'ACCEPTED'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, userId);
            ps.setInt(3, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(rs.getInt("id") + Protocol.FIELD_SEP + rs.getString("username")
                            + Protocol.FIELD_SEP + rs.getString("email"));
                }
            }
        }
        return results;
    }
    // Person 3 & 4: Wish list items (own + friends')

    //Returns rows: itemId,,name,,description,,defaultPrice
    public List<String> getAvailableItems() throws SQLException {
        List<String> results = new ArrayList<>();
        String sql = "SELECT id, name, description, default_price FROM items";
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                results.add(rs.getInt("id") + Protocol.FIELD_SEP +
                        rs.getString("name") + Protocol.FIELD_SEP +
                        rs.getString("description") + Protocol.FIELD_SEP +
                        rs.getBigDecimal("default_price"));
            }
        }
        return results;
    }

    public int createWishlistItem(int userId, int itemId, double price) throws SQLException {
        String sql = "INSERT INTO wishlist_items (user_id, item_id, price) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId);
            ps.setInt(2, itemId);
            ps.setDouble(3, price);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public void updateWishlistItemPrice(int wishlistItemId, double newPrice) throws SQLException {
        String sql = "UPDATE wishlist_items SET price = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDouble(1, newPrice);
            ps.setInt(2, wishlistItemId);
            ps.executeUpdate();
        }
    }

    public void deleteWishlistItem(int wishlistItemId) throws SQLException {
        String sql = "DELETE FROM wishlist_items WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, wishlistItemId);
            ps.executeUpdate();
        }
    }

    /** Returns rows: wishlistItemId,,itemName,,price,,amountRaised,,isCompleted */
    public List<String> getWishlist(int userId) throws SQLException {
        List<String> results = new ArrayList<>();
        String sql = "SELECT w.id, i.name, w.price, w.amount_raised, w.is_completed " +
                "FROM wishlist_items w JOIN items i ON w.item_id = i.id WHERE w.user_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(rs.getInt("id") + Protocol.FIELD_SEP +
                            rs.getString("name") + Protocol.FIELD_SEP +
                            rs.getBigDecimal("price") + Protocol.FIELD_SEP +
                            rs.getBigDecimal("amount_raised") + Protocol.FIELD_SEP +
                            rs.getBoolean("is_completed"));
                }
            }
        }
        return results;
    }

    // Person 5: Contributions & notifications
    public boolean contribute(int contributorId, int wishlistItemId, double amount) throws SQLException {
        String insertSql = "INSERT INTO contributions (wishlist_item_id, contributor_id, amount) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(insertSql)) {
            ps.setInt(1, wishlistItemId);
            ps.setInt(2, contributorId);
            ps.setDouble(3, amount);
            ps.executeUpdate();
        }

        String updateSql = "UPDATE wishlist_items SET amount_raised = amount_raised + ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(updateSql)) {
            ps.setDouble(1, amount);
            ps.setInt(2, wishlistItemId);
            ps.executeUpdate();
        }

        // Check if completed
        String checkSql = "SELECT user_id, price, amount_raised, is_completed FROM wishlist_items WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(checkSql)) {
            ps.setInt(1, wishlistItemId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double price = rs.getDouble("price");
                    double raised = rs.getDouble("amount_raised");
                    boolean alreadyCompleted = rs.getBoolean("is_completed");
                    int receiverId = rs.getInt("user_id");

                    if (!alreadyCompleted && raised >= price) {
                        markWishlistItemCompleted(wishlistItemId);
                        notify(contributorId, "BUYER_COMPLETED", "You completed a gift item price!");
                        notify(receiverId, "RECEIVER_BOUGHT", "One of your wish list items was fully funded!");
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void markWishlistItemCompleted(int wishlistItemId) throws SQLException {
        String sql = "UPDATE wishlist_items SET is_completed = TRUE WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, wishlistItemId);
            ps.executeUpdate();
        }
    }

    public void notify(int userId, String type, String message) throws SQLException {
        String sql = "INSERT INTO notifications (user_id, type, message) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, type);
            ps.setString(3, message);
            ps.executeUpdate();
        }
    }

    // Returns rows: id,,type,,message,,isRead
    public List<String> getNotifications(int userId) throws SQLException {
        List<String> results = new ArrayList<>();
        String sql = "SELECT id, type, message, is_read FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(rs.getInt("id") + Protocol.FIELD_SEP +
                            rs.getString("type") + Protocol.FIELD_SEP +
                            rs.getString("message") + Protocol.FIELD_SEP +
                            rs.getBoolean("is_read"));
                }
            }
        }
        return results;
    }

    public void markNotificationRead(int notificationId) throws SQLException {
        String sql = "UPDATE notifications SET is_read = TRUE WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, notificationId);
            ps.executeUpdate();
        }
    }
}


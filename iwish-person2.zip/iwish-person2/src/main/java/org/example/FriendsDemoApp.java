package org.example;

import org.example.net.Session;

import javax.swing.*;

/**
 * Run this to see the real Friends screen talking to the actual server.
 * Uses Session.currentUserId (set it before running, or change it here).
 */
public class FriendsDemoApp {

    public static void main(String[] args) {

        Ui.installLookAndFeel();

        SwingUtilities.invokeLater(() -> {

            JFrame frame = new JFrame("My Friends");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(820, 640);
            frame.setLocationRelativeTo(null);

            FriendsPanel panel = new FriendsPanel(new RealFriendsApi(), Session.currentUserId);

            // Person 4 plugs their real "view friend's wishlist" screen in here.
            panel.setOnViewWishList(friend ->
                    JOptionPane.showMessageDialog(
                            frame,
                            "Open " + friend.getUsername() + "'s wish list here (Person 4's screen).",
                            "View Wish List",
                            JOptionPane.INFORMATION_MESSAGE
                    )
            );

            frame.setContentPane(panel);
            frame.setVisible(true);
        });
    }
}

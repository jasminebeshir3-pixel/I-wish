package org.example;


import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;

/**
 * The complete Friends screen (Person 2). Drop it into the main window like any JPanel:
 *
 *     FriendsPanel friends = new FriendsPanel(new RemoteFriendsApi(ServerConnection.getInstance()), loggedInUserId);
 *     friends.setOnViewWishList(friend -> showFriendWishList(friend));   // Person 4 plugs in here
 *     mainTabs.add("Friends", friends);
 *
 * Three tabs:
 *   My Friends  - list, search, view wish list, remove friend
 *   Requests    - accept / decline requests you received, cancel requests you sent
 *   Add Friend  - send a friend request by username or email
 *
 * All network calls run in the background (SwingWorker) so the window never freezes,
 * and the lists refresh themselves every few seconds while the panel is visible.
 */
@SuppressWarnings("serial")
public class FriendsPanel extends JPanel {

    private static final int REFRESH_MS = 15000;

    private final FriendsApi api;
    private final int userId;
    private Consumer<FriendDTO> onViewWishList = friend -> { };

    // list data
    private final DefaultListModel<FriendDTO> friendsModel = new DefaultListModel<>();
    private final DefaultListModel<FriendRequestDTO> receivedModel = new DefaultListModel<>();
    private final DefaultListModel<FriendRequestDTO> sentModel = new DefaultListModel<>();
    private List<FriendDTO> allFriends = new ArrayList<>();

    // widgets
    private final Ui.EmptyAwareList<FriendDTO> friendsList = new Ui.EmptyAwareList<>(friendsModel);
    private final Ui.EmptyAwareList<FriendRequestDTO> receivedList = new Ui.EmptyAwareList<>(receivedModel);
    private final Ui.EmptyAwareList<FriendRequestDTO> sentList = new Ui.EmptyAwareList<>(sentModel);
    private final JTextField searchField = new JTextField();
    private final JTextField addField = new JTextField();
    private final JLabel addStatus = new JLabel(" ");
    private final JLabel statusLabel = new JLabel(" ");
    private final JTabbedPane tabs = new JTabbedPane();

    private final Ui.RoundedButton refreshBtn = new Ui.RoundedButton("Refresh", Ui.NEUTRAL);
    private final Ui.RoundedButton viewBtn = new Ui.RoundedButton("View Wish List", Ui.PRIMARY);
    private final Ui.RoundedButton removeBtn = new Ui.RoundedButton("Remove Friend", Ui.DANGER);
    private final Ui.RoundedButton acceptBtn = new Ui.RoundedButton("Accept", Ui.SUCCESS);
    private final Ui.RoundedButton declineBtn = new Ui.RoundedButton("Decline", Ui.DANGER);
    private final Ui.RoundedButton cancelBtn = new Ui.RoundedButton("Cancel Request", Ui.NEUTRAL);
    private final Ui.RoundedButton sendBtn = new Ui.RoundedButton("Send Request", Ui.PRIMARY);

    private final Timer refreshTimer;
    private boolean statusIsError;

    public FriendsPanel(FriendsApi api, int userId) {
        super(new BorderLayout(0, 14));
        this.api = api;
        this.userId = userId;

        setBackground(Ui.BG);
        setBorder(new EmptyBorder(20, 24, 12, 24));

        tabs.setFont(Ui.font(Font.BOLD, 14));
        tabs.addTab("My Friends", buildFriendsTab());
        tabs.addTab("Requests", buildRequestsTab());
        tabs.addTab("Add Friend", buildAddTab());

        statusLabel.setFont(Ui.font(Font.PLAIN, 13));

        add(buildHeader(), BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        wireActions();
        updateButtons();
        refreshTimer = new Timer(REFRESH_MS, e -> refresh());
    }

    // =============================================================== public API for teammates

    /** Person 4: called when the user presses "View Wish List" (or double-clicks a friend). */
    public void setOnViewWishList(Consumer<FriendDTO> handler) {
        this.onViewWishList = handler == null ? friend -> { } : handler;
    }

    /** The friend currently highlighted in the list, or null. */
    public FriendDTO getSelectedFriend() {
        return friendsList.getSelectedValue();
    }

    /** Reloads friends and requests from the server (also runs automatically). */
    public void refresh() {
        async(() -> new Snapshot(api.getFriends(userId), api.getReceivedRequests(userId),
                        api.getSentRequests(userId)),
                this::applySnapshot,
                this::showError);
    }

    @Override
    public void addNotify() {
        super.addNotify();
        refresh();
        refreshTimer.start();
    }

    @Override
    public void removeNotify() {
        refreshTimer.stop();
        super.removeNotify();
    }

    // =============================================================== building the screen

    private JPanel buildHeader() {
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.add(Ui.label("Friends", Font.BOLD, 28, Ui.TEXT));
        titles.add(Box.createVerticalStrut(2));
        titles.add(Ui.label("Add friends, answer requests and peek at their wish lists.",
                Font.PLAIN, 13, Ui.MUTED));

        JPanel east = new JPanel(new GridBagLayout());
        east.setOpaque(false);
        east.add(refreshBtn);

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(titles, BorderLayout.WEST);
        header.add(east, BorderLayout.EAST);
        return header;
    }

    private JPanel buildFriendsTab() {
        Ui.styleField(searchField);
        Ui.styleList(friendsList);
        friendsList.setEmptyText("No friends yet - add some from the \"Add Friend\" tab!");

        JPanel top = new JPanel(new BorderLayout(10, 0));
        top.setOpaque(false);
        top.add(Ui.label("Search", Font.BOLD, 13, Ui.MUTED), BorderLayout.WEST);
        top.add(searchField, BorderLayout.CENTER);

        JPanel p = Ui.card(new BorderLayout(0, 12));
        p.add(top, BorderLayout.NORTH);
        p.add(Ui.scroll(friendsList), BorderLayout.CENTER);
        p.add(Ui.buttonBar(viewBtn, removeBtn), BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildRequestsTab() {
        Ui.styleList(receivedList);
        Ui.styleList(sentList);
        receivedList.setEmptyText("No new requests right now.");
        sentList.setEmptyText("You have no pending requests.");

        JPanel p = Ui.card(new GridLayout(2, 1, 0, 14));
        p.add(section("Requests sent to you", receivedList, Ui.buttonBar(declineBtn, acceptBtn)));
        p.add(section("Requests you sent", sentList, Ui.buttonBar(cancelBtn)));
        return p;
    }

    private JPanel section(String title, JComponent list, JComponent buttons) {
        JPanel s = new JPanel(new BorderLayout(0, 8));
        s.setOpaque(false);
        s.add(Ui.label(title, Font.BOLD, 15, Ui.TEXT), BorderLayout.NORTH);
        s.add(Ui.scroll(list), BorderLayout.CENTER);
        s.add(buttons, BorderLayout.SOUTH);
        return s;
    }

    private JPanel buildAddTab() {
        Ui.styleField(addField);
        addField.setPreferredSize(new Dimension(400, 42));
        addField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        addStatus.setFont(Ui.font(Font.PLAIN, 13));

        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));

        JLabel title = Ui.label("Add a friend", Font.BOLD, 22, Ui.TEXT);
        JLabel hint = Ui.label("Type your friend's username or email and we'll send them a request.",
                Font.PLAIN, 13, Ui.MUTED);
        for (JComponent c : new JComponent[] {title, hint, addField, sendBtn, addStatus}) {
            c.setAlignmentX(LEFT_ALIGNMENT);
        }
        box.add(title);
        box.add(Box.createVerticalStrut(6));
        box.add(hint);
        box.add(Box.createVerticalStrut(18));
        box.add(addField);
        box.add(Box.createVerticalStrut(12));
        box.add(sendBtn);
        box.add(Box.createVerticalStrut(12));
        box.add(addStatus);

        JPanel p = Ui.card(new GridBagLayout());
        p.add(box);
        return p;
    }

    private void wireActions() {
        Ui.onChange(searchField, this::applyFriendFilter);

        friendsList.addListSelectionListener(e -> updateButtons());
        receivedList.addListSelectionListener(e -> updateButtons());
        sentList.addListSelectionListener(e -> updateButtons());

        friendsList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i = friendsList.locationToIndex(e.getPoint());
                Rectangle cell = i < 0 ? null : friendsList.getCellBounds(i, i);
                if (e.getClickCount() == 2 && cell != null && cell.contains(e.getPoint())) {
                    viewWishList();
                }
            }
        });

        refreshBtn.addActionListener(e -> refresh());
        viewBtn.addActionListener(e -> viewWishList());
        removeBtn.addActionListener(e -> removeSelectedFriend());
        acceptBtn.addActionListener(e -> acceptSelected());
        declineBtn.addActionListener(e -> declineSelected());
        cancelBtn.addActionListener(e -> cancelSelected());
        sendBtn.addActionListener(e -> sendRequest());
        addField.addActionListener(e -> sendRequest());
    }

    // =============================================================== user actions

    private void viewWishList() {
        FriendDTO friend = friendsList.getSelectedValue();
        if (friend != null) {
            onViewWishList.accept(friend);
        }
    }

    private void removeSelectedFriend() {
        FriendDTO friend = friendsList.getSelectedValue();
        if (friend == null) {
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this,
                "Remove " + friend.getUsername() + " from your friends?\n"
                        + "You won't see each other's wish lists any more.",
                "Remove friend", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            runAction(() -> api.removeFriend(userId, friend.getId()));
        }
    }

    private void acceptSelected() {
        FriendRequestDTO r = receivedList.getSelectedValue();
        if (r != null) {
            runAction(() -> api.acceptRequest(userId, r.getRequestId()));
        }
    }

    private void declineSelected() {
        FriendRequestDTO r = receivedList.getSelectedValue();
        if (r != null) {
            runAction(() -> api.declineRequest(userId, r.getRequestId()));
        }
    }

    private void cancelSelected() {
        FriendRequestDTO r = sentList.getSelectedValue();
        if (r != null) {
            runAction(() -> api.cancelRequest(userId, r.getRequestId()));
        }
    }

    private void sendRequest() {
        String text = addField.getText().trim();
        if (text.isEmpty()) {
            setAddStatus("Please type your friend's username or email.", false);
            return;
        }
        sendBtn.setEnabled(false);
        setAddStatus("Sending...", true);
        async(() -> api.sendRequest(userId, text),
                message -> {
                    addField.setText("");
                    setAddStatus(message, true);
                    sendBtn.setEnabled(true);
                    refresh();
                },
                error -> {
                    setAddStatus(error, false);
                    sendBtn.setEnabled(true);
                });
    }

    /** Runs a server action that returns a message, shows the message, then reloads the lists. */
    private void runAction(Callable<String> action) {
        async(action,
                message -> {
                    setStatus(message, true);
                    refresh();
                },
                this::showError);
    }

    // =============================================================== updating the screen

    private static final class Snapshot {
        final List<FriendDTO> friends;
        final List<FriendRequestDTO> received;
        final List<FriendRequestDTO> sent;

        Snapshot(List<FriendDTO> friends, List<FriendRequestDTO> received, List<FriendRequestDTO> sent) {
            this.friends = friends;
            this.received = received;
            this.sent = sent;
        }
    }

    private void applySnapshot(Snapshot s) {
        allFriends = s.friends;
        replaceModel(receivedList, receivedModel, s.received, FriendRequestDTO::getRequestId);
        replaceModel(sentList, sentModel, s.sent, FriendRequestDTO::getRequestId);
        applyFriendFilter();

        tabs.setTitleAt(0, "My Friends (" + s.friends.size() + ")");
        tabs.setTitleAt(1, s.received.isEmpty() ? "Requests" : "Requests (" + s.received.size() + " new)");
        updateButtons();

        if (statusIsError) { // the connection is back - clear the old error
            setStatus(" ", true);
        }
    }

    private void applyFriendFilter() {
        String q = searchField.getText().trim().toLowerCase();
        List<FriendDTO> shown = new ArrayList<>();
        for (FriendDTO f : allFriends) {
            if (q.isEmpty() || f.getUsername().toLowerCase().contains(q)
                    || f.getEmail().toLowerCase().contains(q)) {
                shown.add(f);
            }
        }
        friendsList.setEmptyText(allFriends.isEmpty()
                ? "No friends yet - add some from the \"Add Friend\" tab!"
                : "No friends match your search.");
        replaceModel(friendsList, friendsModel, shown, FriendDTO::getId);
    }

    /**
     * Puts new items into a list but (1) keeps the user's selection and (2) does nothing at all
     * when the list did not change, so the auto-refresh never makes the scroll position jump.
     */
    private static <T> void replaceModel(JList<T> list, DefaultListModel<T> model, List<T> items,
                                         ToIntFunction<T> idOf) {
        boolean same = model.size() == items.size();
        for (int i = 0; same && i < items.size(); i++) {
            same = idOf.applyAsInt(model.get(i)) == idOf.applyAsInt(items.get(i));
        }
        if (same) {
            return;
        }
        T selected = list.getSelectedValue();
        int selectedId = selected == null ? Integer.MIN_VALUE : idOf.applyAsInt(selected);
        model.clear();
        int reselect = -1;
        for (int i = 0; i < items.size(); i++) {
            model.addElement(items.get(i));
            if (idOf.applyAsInt(items.get(i)) == selectedId) {
                reselect = i;
            }
        }
        if (reselect >= 0) {
            list.setSelectedIndex(reselect);
        }
    }

    private void updateButtons() {
        boolean friendSelected = friendsList.getSelectedValue() != null;
        viewBtn.setEnabled(friendSelected);
        removeBtn.setEnabled(friendSelected);
        boolean receivedSelected = receivedList.getSelectedValue() != null;
        acceptBtn.setEnabled(receivedSelected);
        declineBtn.setEnabled(receivedSelected);
        cancelBtn.setEnabled(sentList.getSelectedValue() != null);
    }

    private void setStatus(String text, boolean ok) {
        statusIsError = !ok;
        statusLabel.setForeground(ok ? Ui.OK_TEXT : Ui.DANGER);
        statusLabel.setText(text);
    }

    private void setAddStatus(String text, boolean ok) {
        addStatus.setForeground(ok ? Ui.OK_TEXT : Ui.DANGER);
        addStatus.setText(text);
    }

    private void showError(String message) {
        setStatus(message, false);
    }

    // =============================================================== background work

    /** Runs {@code work} off the Swing thread, then calls onSuccess / onError back ON the Swing thread. */
    private <T> void async(Callable<T> work, Consumer<T> onSuccess, Consumer<String> onError) {
        new SwingWorker<T, Void>() {
            @Override
            protected T doInBackground() throws Exception {
                return work.call();
            }

            @Override
            protected void done() {
                try {
                    onSuccess.accept(get());
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    onError.accept(cause instanceof FriendsException
                            ? cause.getMessage()
                            : "Unexpected problem: " + cause);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }.execute();
    }
}

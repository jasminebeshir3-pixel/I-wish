package org.example;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * A pending friend request.
 * For a RECEIVED request, userId/username/email describe the person who sent it.
 * For a SENT request, they describe the person it was sent to.
 */
public class FriendRequestDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private final int requestId;
    private final int userId;
    private final String username;
    private final String email;
    private final LocalDateTime createdAt;

    public FriendRequestDTO(int requestId, int userId, String username, String email, LocalDateTime createdAt) {
        this.requestId = requestId;
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.createdAt = createdAt;
    }

    public int getRequestId() { return requestId; }
    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return username;
    }
}

package org.example;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {

    private static final int PORT = 5000;

    private ServerSocket serverSocket;
    private final ExecutorService clientPool = Executors.newCachedThreadPool();
    private DatabaseManager db;
    private volatile boolean running = false;

    public void start() {
        try {
            db = new DatabaseManager();
            serverSocket = new ServerSocket(PORT);
            running = true;
            System.out.println("[Server] Started on port " + PORT);

            while (running) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("[Server] Client connected: " + clientSocket.getInetAddress());
                    clientPool.execute(new ClientHandler(clientSocket, db));
                } catch (IOException e) {
                    if (running) {
                        System.err.println("[Server] Error accepting client: " + e.getMessage());
                    }
                    // if !running, this exception is expected (socket closed by stop())
                }
            }
        } catch (IOException e) {
            System.err.println("[Server] Could not start: " + e.getMessage());
        }
    }

    public void stop() {
        running = false;
        try {
            if (serverSocket != null && !serverSocket.isClosed()) serverSocket.close();
        } catch (IOException e) {
            System.err.println("[Server] Error closing server socket: " + e.getMessage());
        }
        clientPool.shutdown();
        if (db != null) db.disconnect();
        System.out.println("[Server] Stopped.");
    }

    public static void main(String[] args) {
        Server server = new Server();

        // Allow graceful shutdown with Ctrl+C
        Runtime.getRuntime().addShutdownHook(new Thread(server::stop));

        server.start();
    }
}

package org.example;


import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.format.DateTimeFormatter;

/**
 * Shared look & feel for the whole i-Wish client: colours, fonts, rounded buttons,
 * avatar circles. The spec asks for ONE consistent design, so the other team members
 * should reuse these helpers (or copy the colours) for their screens too.
 */
public final class Ui {

    // ---- palette --------------------------------------------------------------------------
    public static final Color BG        = new Color(0xF5F6FA);
    public static final Color CARD      = Color.WHITE;
    public static final Color PRIMARY   = new Color(0x6C5CE7);
    public static final Color SUCCESS   = new Color(0x00B894);
    public static final Color OK_TEXT   = new Color(0x00876C);
    public static final Color DANGER    = new Color(0xD63031);
    public static final Color NEUTRAL   = new Color(0x636E72);
    public static final Color TEXT      = new Color(0x2D3436);
    public static final Color MUTED     = new Color(0x636E72);
    public static final Color BORDER    = new Color(0xDFE6E9);
    public static final Color SELECTION = new Color(0xEDEBFC);

    private static final Color[] AVATAR_COLORS = {
        new Color(0x6C5CE7), new Color(0x00B894), new Color(0xE17055), new Color(0x0984E3),
        new Color(0xE84393), new Color(0xF39C12), new Color(0x00A8A3), new Color(0x8E44AD)
    };

    private static final DateTimeFormatter WHEN = DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm");

    private Ui() { }

    public static Font font(int style, int size) {
        return new Font(Font.SANS_SERIF, style, size);
    }

    /** Call once at startup. Nimbus looks the most modern on every OS; falls back to the system look. */
    public static void installLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    return;
                }
            }
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // keep the default look
        }
    }

    // ---- small building blocks -----------------------------------------------------------------

    public static JLabel label(String text, int style, int size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    /** A white rounded-ish panel with a thin border and padding. */
    public static JPanel card(LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setBackground(CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(16, 16, 16, 16)));
        return p;
    }

    public static JPanel buttonBar(JComponent... buttons) {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        bar.setOpaque(false);
        for (JComponent b : buttons) {
            bar.add(b);
        }
        return bar;
    }

    public static JScrollPane scroll(JComponent view) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(BorderFactory.createLineBorder(BORDER));
        sp.getViewport().setBackground(CARD);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        return sp;
    }

    public static void styleField(JTextComponent f) {
        f.setFont(font(Font.PLAIN, 14));
        f.setForeground(TEXT);
        f.setBackground(Color.WHITE);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(8, 12, 8, 12)));
    }

    public static <T> void styleList(JList<T> list) {
        list.setCellRenderer(new PersonRenderer());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setBackground(CARD);
        list.setFixedCellHeight(68);
    }

    /** Runs the action whenever the text of the field changes (typing, paste, delete). */
    public static void onChange(JTextComponent field, Runnable action) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { action.run(); }
            @Override public void removeUpdate(DocumentEvent e) { action.run(); }
            @Override public void changedUpdate(DocumentEvent e) { action.run(); }
        });
    }

    // ---- rounded button ------------------------------------------------------------------------

    /** A flat coloured button that looks the same on every look & feel. */
    @SuppressWarnings("serial")
    public static class RoundedButton extends JButton {

        private final Color base;
        private boolean hover;

        public RoundedButton(String text, Color base) {
            super(text);
            this.base = base;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);
            setForeground(Color.WHITE);
            setFont(font(Font.BOLD, 13));
            setBorder(new EmptyBorder(9, 18, 9, 18));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color fill;
            if (!isEnabled()) {
                fill = new Color(0xDFE6E9);
            } else if (getModel().isPressed()) {
                fill = base.darker().darker();
            } else if (hover) {
                fill = base.darker();
            } else {
                fill = base;
            }
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);

            // draw the label ourselves so the text colour is right on every look & feel
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            String label = getText();
            int tx = (getWidth() - fm.stringWidth(label)) / 2;
            int ty = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2.setColor(isEnabled() ? Color.WHITE : new Color(0x8A979C));
            g2.drawString(label, tx, ty);
            g2.dispose();
        }
    }

    // ---- avatar --------------------------------------------------------------------------------

    public static Color colorFor(String name) {
        return AVATAR_COLORS[(name.hashCode() & 0x7fffffff) % AVATAR_COLORS.length];
    }

    /** A coloured circle with the first letter of the name - a friendly stand-in for a profile picture. */
    public static class AvatarIcon implements Icon {

        private final int size;
        private final String letter;
        private final Color color;

        public AvatarIcon(int size, String name) {
            this.size = size;
            this.letter = name == null || name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
            this.color = colorFor(name == null ? "?" : name);
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(color);
            g2.fillOval(x, y, size, size);
            g2.setColor(Color.WHITE);
            g2.setFont(font(Font.BOLD, size / 2));
            FontMetrics fm = g2.getFontMetrics();
            int tx = x + (size - fm.stringWidth(letter)) / 2;
            int ty = y + (size - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(letter, tx, ty);
            g2.dispose();
        }

        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }
    }

    // ---- lists ---------------------------------------------------------------------------------

    /** A JList that shows a friendly message when it has no items. */
    @SuppressWarnings("serial")
    public static class EmptyAwareList<T> extends JList<T> {

        private String emptyText = "";

        public EmptyAwareList(ListModel<T> model) {
            super(model);
        }

        public void setEmptyText(String text) {
            this.emptyText = text;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getModel().getSize() == 0 && !emptyText.isEmpty()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(font(Font.PLAIN, 14));
                g2.setColor(MUTED);
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(emptyText)) / 2;
                int y = Math.min(getHeight() / 2, 90) + fm.getAscent() / 2;
                g2.drawString(emptyText, Math.max(x, 12), y);
                g2.dispose();
            }
        }
    }

    /** Draws one row: avatar circle, name, and a small grey second line. Works for friends and requests. */
    @SuppressWarnings("serial")
    public static class PersonRenderer extends JPanel implements ListCellRenderer<Object> {

        private final JLabel avatar = new JLabel();
        private final JLabel name = new JLabel();
        private final JLabel sub = new JLabel();

        public PersonRenderer() {
            super(new BorderLayout(14, 0));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER), new EmptyBorder(10, 14, 10, 14)));
            name.setFont(font(Font.BOLD, 15));
            name.setForeground(TEXT);
            sub.setFont(font(Font.PLAIN, 12));
            sub.setForeground(MUTED);
            JPanel text = new JPanel(new GridLayout(2, 1));
            text.setOpaque(false);
            text.add(name);
            text.add(sub);
            add(avatar, BorderLayout.WEST);
            add(text, BorderLayout.CENTER);
        }

        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean selected, boolean focused) {
            String n = "";
            String s = "";
            if (value instanceof FriendDTO) {
                FriendDTO f = (FriendDTO) value;
                n = f.getUsername();
                s = f.getEmail();
            } else if (value instanceof FriendRequestDTO) {
                FriendRequestDTO r = (FriendRequestDTO) value;
                n = r.getUsername();
                s = r.getEmail() + "  |  " + WHEN.format(r.getCreatedAt());
            }
            name.setText(n);
            sub.setText(s);
            avatar.setIcon(new AvatarIcon(44, n));
            setBackground(selected ? SELECTION : CARD);
            return this;
        }
    }
}

-- ============================================
-- I-Wish Project Database Schema
-- Run this once to create the database and all tables.
-- ============================================

CREATE DATABASE IF NOT EXISTS iwish_db;
USE iwish_db;

CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    password      VARCHAR(255) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- status: 'PENDING', 'ACCEPTED', 'DECLINED'
CREATE TABLE IF NOT EXISTS friends (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    friend_id     INT NOT NULL,
    status        VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_pair (user_id, friend_id)
);

-- Catalog of items available to add to a wish list
CREATE TABLE IF NOT EXISTS items (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    description   VARCHAR(255),
    image_path    VARCHAR(255),
    default_price DECIMAL(10,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS wishlist_items (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    item_id       INT NOT NULL,
    price         DECIMAL(10,2) NOT NULL,
    amount_raised DECIMAL(10,2) NOT NULL DEFAULT 0,
    is_completed  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id)
);

CREATE TABLE IF NOT EXISTS contributions (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    wishlist_item_id  INT NOT NULL,
    contributor_id    INT NOT NULL,
    amount            DECIMAL(10,2) NOT NULL,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (wishlist_item_id) REFERENCES wishlist_items(id) ON DELETE CASCADE,
    FOREIGN KEY (contributor_id)   REFERENCES users(id)
);

-- type: 'BUYER_COMPLETED' or 'RECEIVER_BOUGHT'
CREATE TABLE IF NOT EXISTS notifications (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    type          VARCHAR(30) NOT NULL,
    message       VARCHAR(255) NOT NULL,
    is_read       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample catalog items
INSERT INTO items (name, description, default_price) VALUES
('PlayStation 5', 'Gaming console', 500.00),
('iPhone 16', 'Smartphone', 1000.00),
('Book: Clean Code', 'Programming book', 25.00),
('Headphones', 'Wireless headphones', 80.00);

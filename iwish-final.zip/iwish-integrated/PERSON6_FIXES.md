# Person 6 — fixes

Everything below was done inside `server/`, `net/` and `MainDashboard.java`
(Person 6's + shared "integration" territory), plus one required one-line
change in `person4/FriendsWishListsGUI.java` — flagged clearly below so it's
easy to explain in a PR.

## New files
- `server/PasswordUtil.java` — SHA-256 password hashing.

## Bugs fixed

1. **Concurrency bug (would show up the moment 2+ clients are open at once):**
   `Server.java` used to create ONE shared `DatabaseManager` and hand the same
   JDBC `Connection` to every client thread. JDBC connections aren't
   thread-safe, so two people using the app at the same time could corrupt
   each other's queries. Now every `ClientHandler` opens its own connection.

2. **`GET_FRIEND_WISHLIST` had no authorization check** — any user id could
   be passed as "friend" and it would return that person's full wish list,
   friends or not. It now requires the caller's own id too
   (`GET_FRIEND_WISHLIST|myUserId|friendUserId`) and checks `areFriends()`
   before returning anything. **This is the one line that changed outside
   Person 6's files:** `person4/FriendsWishListsGUI.java` now sends its own
   `currentUserId` as well.

3. **Re-sending a friend request after a decline crashed with a raw SQL
   error** (`UNIQUE(user_id, friend_id)` constraint + plain `INSERT`). Fixed
   with `INSERT ... ON DUPLICATE KEY UPDATE`.

4. **Passwords were stored in plain text.** Now hashed with SHA-256
   (`PasswordUtil`) on register, and compared as a hash on login.

5. **No validation against the protocol's own delimiters.** A username,
   password, or email containing `|`, `,,` or `;;` would silently corrupt
   every future request. Now rejected at registration.

6. **Missing contribution guards:** you could contribute to your *own* wish
   list item, or keep contributing to one that's already fully funded.
   Both now rejected with a clear error message. Also added a friend check
   (same as #2) so you can only contribute to an actual friend's item.

7. **Money was `double`** in `DatabaseManager`'s wishlist/contribution logic —
   floating point rounding errors risk the `raised >= price` completion
   check misfiring. Switched to `BigDecimal` internally. No wire-format or
   client-side change needed anywhere else — it was always just decimal
   text on the socket.

8. **"View Wish List" from the Friends screen was a placeholder dialog**
   (`"Open X's wish list here (Person 4's screen)"`) instead of actually
   opening it. `MainDashboard.openFriends()` now opens the real
   `FriendsWishListsGUI`. (It opens the general screen rather than
   auto-selecting that exact friend — a nice-to-have for later, not done here.)

9. **Socket leak in `MyWishListFrame`** — the `WishlistClient` opened in
   `MainDashboard.openMyWishList()` was never closed. Now closed on window-close.

## Spec-compliance pass (final)
- **Server Start/Stop (spec 11):** new `server/ServerGUI.java` window with Start /
  Stop buttons, status, and a live log. `Server` can now be started and stopped
  repeatedly, and Stop also disconnects every connected client.
- **Notifications (spec 8 & 9):** when an item's price is fully covered, *every*
  friend who contributed gets a "gift completed" notification (before, only the
  last contributor did), and the owner's notification now names the friend(s)
  who bought it and the item.
- **`pom.xml`:** `mainClass` pointed at a class that doesn't exist
  (`org.example.Server`); now `org.example.server.ServerGUI`.
- **DB credentials** can be set with `IWISH_DB_USER` / `IWISH_DB_PASS`.

## Verified end-to-end (manually re-tested against a live MySQL + the actual
compiled client/server code, running as two separate processes):
- wrong password rejected (hashing works)
- decline → re-send friend request no longer crashes
- a non-friend is rejected from viewing a wish list; an actual friend can
- self-contribution rejected; over-contributing to a completed item rejected
- contribution that completes an item saves a notification for BOTH the
  contributor and the wish list owner (visible in the Notifications screen)

## Known limitations not addressed in this pass (flagging honestly, not fixed)
- Still no real session/auth — the client tells the server which userId it
  is on every request; there's no token proving it. Fine for a course
  project, but worth knowing.
- Person 3's `WishlistClient` still uses a different networking style
  (persistent socket per screen) than everyone else's `ServerClient`
  (one-shot socket per call). Both work; just inconsistent.
- "View Wish List" from the Friends screen opens the friends'-wishlists
  screen generally rather than auto-selecting that specific friend.

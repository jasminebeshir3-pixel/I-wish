package org.example.person5;

import org.example.net.ServerClient;
import org.example.net.Session;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ContributionsGUI extends JFrame {

    private final DefaultListModel<String> itemModel = new DefaultListModel<>();
    private final JList<String> itemList = new JList<>(itemModel);

    // Keeps the parsed server rows in the same order as itemModel,
    // so we can pull out real ids/prices when the user picks items.
    private final List<String[]> itemRows = new ArrayList<>();

    private final int friendId;      // whose wishlist we're browsing
    private final int currentUserId; // who is contributing

    /** Standalone/test constructor - browses friend id 3 ("sarah" test account) as the current session user. */
    public ContributionsGUI() {
        this(3, Session.currentUserId);
    }

    public ContributionsGUI(int friendId, int currentUserId) {

        this.friendId = friendId;
        this.currentUserId = currentUserId;

        setTitle("Friends' Wishlist Items");
        setSize(680, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 16));
        mainPanel.setBackground(Ui.BG);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        mainPanel.add(Ui.label("Select Items to Contribute", Font.BOLD, 22, Ui.TEXT), BorderLayout.NORTH);

        itemList.setFont(Ui.font(Font.PLAIN, 15));
        itemList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        itemList.setBackground(Ui.CARD);
        itemList.setSelectionBackground(Ui.SELECTION);
        itemList.setSelectionForeground(Ui.TEXT);
        mainPanel.add(Ui.scroll(itemList), BorderLayout.CENTER);

        Ui.RoundedButton contributeButton = new Ui.RoundedButton("Contribute", Ui.PRIMARY);
        Ui.RoundedButton closeButton = new Ui.RoundedButton("Close", Ui.NEUTRAL);
        mainPanel.add(Ui.buttonBar(closeButton, contributeButton), BorderLayout.SOUTH);

        contributeButton.addActionListener(e -> openContribution());
        closeButton.addActionListener(e -> dispose());

        add(mainPanel);

        loadItems();
    }

    // ==========================================
    // Load Items (Person 6: GET_FRIEND_WISHLIST)
    // ==========================================

    private void loadItems() {

        itemModel.clear();
        itemRows.clear();

        String response = ServerClient.send("GET_FRIEND_WISHLIST|" + friendId);

        if (!ServerClient.isOk(response)) {
            JOptionPane.showMessageDialog(this,
                    "Could not load wishlist: " + ServerClient.dataOf(response),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (String[] row : ServerClient.parseRows(ServerClient.dataOf(response))) {
            boolean completed = Boolean.parseBoolean(row[4]);
            if (completed) continue; // nothing to contribute to on a finished item

            String display =
                    "ID:" + row[0] +
                    " | " + row[1] +
                    " | Price:$" + row[2] +
                    " | Raised:$" + row[3];

            itemModel.addElement(display);
            itemRows.add(row);
        }

        if (itemModel.isEmpty()) {
            itemModel.addElement("No open wishlist items.");
        }
    }

    private void openContribution() {

        int[] selectedIndices = itemList.getSelectedIndices();

        if (selectedIndices.length == 0) {
            JOptionPane.showMessageDialog(this,
                    "Please select at least one item.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        for (int index : selectedIndices) {
            if (index >= itemRows.size()) continue;

            String[] row = itemRows.get(index);
            int wishlistItemId = Integer.parseInt(row[0]);
            String itemName = row[1];
            double price = Double.parseDouble(row[2]);
            double raised = Double.parseDouble(row[3]);

            ContributionGUI contributionGUI = new ContributionGUI(
                    wishlistItemId, itemName, price, raised, currentUserId
            );
            contributionGUI.setVisible(true);
        }
    }

    public static void main(String[] args) {
        Ui.installLookAndFeel();
        SwingUtilities.invokeLater(() -> {
            ContributionsGUI gui = new ContributionsGUI();
            gui.setVisible(true);
        });
    }
}

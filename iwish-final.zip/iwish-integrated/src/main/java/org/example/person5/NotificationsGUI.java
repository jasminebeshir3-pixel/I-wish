package org.example.person5;

import org.example.net.ServerClient;
import org.example.net.Session;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class NotificationsGUI extends JFrame {

    private final DefaultListModel<String> notificationModel = new DefaultListModel<>();
    private final JList<String> notificationList = new JList<>(notificationModel);

    // Maps each displayed row back to its real notification id
    private final Map<Integer, Integer> notificationIds = new HashMap<>();

    private final int currentUserId;

    public NotificationsGUI() {
        this(Session.currentUserId);
    }

    public NotificationsGUI(int currentUserId) {

        this.currentUserId = currentUserId;

        setTitle("Notifications");
        setSize(600, 460);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 16));
        mainPanel.setBackground(Ui.BG);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = Ui.label("Notifications", Font.BOLD, 24, Ui.TEXT);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        notificationList.setFont(Ui.font(Font.PLAIN, 16));
        notificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        notificationList.setBackground(Ui.CARD);
        notificationList.setSelectionBackground(Ui.SELECTION);
        notificationList.setSelectionForeground(Ui.TEXT);
        mainPanel.add(Ui.scroll(notificationList), BorderLayout.CENTER);

        Ui.RoundedButton markReadButton = new Ui.RoundedButton("Mark as Read", Ui.SUCCESS);
        Ui.RoundedButton refreshButton = new Ui.RoundedButton("Refresh", Ui.PRIMARY);
        Ui.RoundedButton closeButton = new Ui.RoundedButton("Close", Ui.NEUTRAL);

        mainPanel.add(Ui.buttonBar(closeButton, refreshButton, markReadButton), BorderLayout.SOUTH);

        markReadButton.addActionListener(e -> markSelectedAsRead());
        refreshButton.addActionListener(e -> loadNotifications());
        closeButton.addActionListener(e -> dispose());

        add(mainPanel);

        loadNotifications();
    }

    // ==========================================
    // Load Notifications (Person 6: GET_NOTIFICATIONS)
    // ==========================================

    private void loadNotifications() {

        notificationModel.clear();
        notificationIds.clear();

        String response = ServerClient.send("GET_NOTIFICATIONS|" + currentUserId);

        if (!ServerClient.isOk(response)) {
            JOptionPane.showMessageDialog(this,
                    "Could not load notifications: " + ServerClient.dataOf(response),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int index = 0;
        for (String[] row : ServerClient.parseRows(ServerClient.dataOf(response))) {
            // row = [id, type, message, isRead]
            int notificationId = Integer.parseInt(row[0]);
            String message = row[2];
            boolean isRead = Boolean.parseBoolean(row[3]);

            String display = (isRead ? "READ" : "UNREAD") + " | " + message;

            notificationModel.addElement(display);
            notificationIds.put(index, notificationId);
            index++;
        }

        if (notificationModel.isEmpty()) {
            notificationModel.addElement("No notifications yet.");
        }
    }

    // ==========================================
    // Mark Selected Notification as Read
    // (Person 6: MARK_NOTIFICATION_READ)
    // ==========================================

    private void markSelectedAsRead() {

        int selectedIndex = notificationList.getSelectedIndex();

        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a notification first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String selected = notificationModel.getElementAt(selectedIndex);

        if (selected.startsWith("READ")) {
            JOptionPane.showMessageDialog(this,
                    "This notification is already marked as read.",
                    "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Integer notificationId = notificationIds.get(selectedIndex);
        if (notificationId == null) return;

        String response = ServerClient.send("MARK_NOTIFICATION_READ|" + notificationId);

        if (!ServerClient.isOk(response)) {
            JOptionPane.showMessageDialog(this,
                    "Could not mark as read: " + ServerClient.dataOf(response),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String updated = selected.replaceFirst("UNREAD", "READ");
        notificationModel.setElementAt(updated, selectedIndex);

        JOptionPane.showMessageDialog(this,
                "Notification marked as read.", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        Ui.installLookAndFeel();
        SwingUtilities.invokeLater(() -> {
            NotificationsGUI gui = new NotificationsGUI();
            gui.setVisible(true);
        });
    }
}

package org.example.person5;

import org.example.net.ServerClient;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;

public class ContributionProgressGUI extends JFrame {

    private double itemPrice;
    private double amountRaised;

    private JLabel raisedLabel;
    private JLabel remainingLabel;
    private JLabel percentageLabel;
    private JProgressBar progressBar;

    /** Standalone/test constructor - shows made-up numbers if run on its own. */
    public ContributionProgressGUI() {
        this(500.00, 250.00);
    }

    /**
     * Real constructor: pass the wishlist item's owner (friendId) and the
     * item's id, and this screen will fetch the latest price/raised amount
     * from the server itself.
     */
    public ContributionProgressGUI(int friendId, int wishlistItemId) {
        this(fetchPrice(friendId, wishlistItemId), fetchRaised(friendId, wishlistItemId));
    }

    private ContributionProgressGUI(double itemPrice, double amountRaised) {

        this.itemPrice = itemPrice;
        this.amountRaised = amountRaised;

        setTitle("Contribution Progress");
        setSize(460, 380);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        JPanel panel = Ui.card(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        int row = 0;

        gbc.gridy = row++;
        panel.add(Ui.label("Gift Contribution Progress", Font.BOLD, 21, Ui.TEXT), gbc);

        raisedLabel = Ui.label("", Font.PLAIN, 15, Ui.OK_TEXT);
        gbc.gridy = row++;
        gbc.insets = new Insets(16, 8, 4, 8);
        panel.add(raisedLabel, gbc);

        remainingLabel = Ui.label("", Font.PLAIN, 15, Ui.NEUTRAL);
        gbc.insets = new Insets(4, 8, 4, 8);
        gbc.gridy = row++;
        panel.add(remainingLabel, gbc);

        percentageLabel = Ui.label("", Font.BOLD, 15, Ui.PRIMARY);
        gbc.gridy = row++;
        panel.add(percentageLabel, gbc);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setForeground(Ui.SUCCESS);
        gbc.gridy = row++;
        gbc.insets = new Insets(16, 8, 16, 8);
        panel.add(progressBar, gbc);

        Ui.RoundedButton closeButton = new Ui.RoundedButton("Close", Ui.NEUTRAL);
        gbc.gridy = row++;
        gbc.insets = new Insets(8, 8, 8, 8);
        panel.add(closeButton, gbc);

        closeButton.addActionListener(e -> dispose());

        add(panel);

        updateProgress();
    }

    private void updateProgress() {

        double remaining = itemPrice - amountRaised;

        int percentage = itemPrice <= 0
                ? 0
                : (int) ((amountRaised / itemPrice) * 100);

        raisedLabel.setText(String.format("Amount Raised: $%.2f", amountRaised));
        remainingLabel.setText(String.format("Remaining: $%.2f", remaining));
        percentageLabel.setText("Completion: " + percentage + "%");
        progressBar.setValue(percentage);
    }

    // ==========================================
    // Fetch latest price/raised for one item
    // (Person 6: GET_FRIEND_WISHLIST, filtered to the matching id)
    // ==========================================

    private static double fetchPrice(int friendId, int wishlistItemId) {
        String[] row = fetchRow(friendId, wishlistItemId);
        return row != null ? Double.parseDouble(row[2]) : 0.0;
    }

    private static double fetchRaised(int friendId, int wishlistItemId) {
        String[] row = fetchRow(friendId, wishlistItemId);
        return row != null ? Double.parseDouble(row[3]) : 0.0;
    }

    private static String[] fetchRow(int friendId, int wishlistItemId) {
        String response = ServerClient.send("GET_FRIEND_WISHLIST|" + friendId);
        if (!ServerClient.isOk(response)) return null;

        for (String[] row : ServerClient.parseRows(ServerClient.dataOf(response))) {
            if (Integer.parseInt(row[0]) == wishlistItemId) {
                return row;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Ui.installLookAndFeel();
        SwingUtilities.invokeLater(() -> {
            ContributionProgressGUI gui = new ContributionProgressGUI();
            gui.setVisible(true);
        });
    }
}

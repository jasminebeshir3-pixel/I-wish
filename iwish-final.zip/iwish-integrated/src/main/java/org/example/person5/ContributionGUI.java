package org.example.person5;

import org.example.net.ServerClient;
import org.example.net.Session;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;

public class ContributionGUI extends JFrame {

    private JLabel raisedLabel;
    private JLabel remainingLabel;
    private JLabel completionLabel;
    private JProgressBar progressBar;

    private JTextField contributionField;

    // Real wishlist item being contributed to
    private final int wishlistItemId;
    private final int contributorUserId;
    private final double itemPrice;
    private double amountRaised;

    /** Standalone/test constructor - keeps working with made-up numbers if run on its own. */
    public ContributionGUI() {
        this(101, "PlayStation 5", 500.00, 250.00, Session.currentUserId);
    }

    /** Real constructor used once a wishlist item has been selected from the server. */
    public ContributionGUI(int wishlistItemId, String itemName, double itemPrice,
                            double amountRaised, int contributorUserId) {

        this.wishlistItemId = wishlistItemId;
        this.itemPrice = itemPrice;
        this.amountRaised = amountRaised;
        this.contributorUserId = contributorUserId;

        setTitle("Make a Contribution");
        setSize(480, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        JPanel panel = Ui.card(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        int row = 0;

        gbc.gridy = row++;
        panel.add(Ui.label("Make a Contribution", Font.BOLD, 22, Ui.TEXT), gbc);

        gbc.insets = new Insets(4, 8, 4, 8);
        gbc.gridy = row++;
        panel.add(Ui.label("Item: " + itemName, Font.PLAIN, 15, Ui.TEXT), gbc);

        gbc.gridy = row++;
        panel.add(Ui.label(String.format("Item Price: $%.2f", itemPrice), Font.PLAIN, 14, Ui.MUTED), gbc);

        raisedLabel = Ui.label(String.format("Amount Raised: $%.2f", amountRaised), Font.PLAIN, 14, Ui.OK_TEXT);
        gbc.gridy = row++;
        panel.add(raisedLabel, gbc);

        remainingLabel = Ui.label(String.format("Remaining: $%.2f", itemPrice - amountRaised), Font.PLAIN, 14, Ui.NEUTRAL);
        gbc.gridy = row++;
        panel.add(remainingLabel, gbc);

        completionLabel = Ui.label("Completion: " + calculateCompletion() + "%", Font.BOLD, 14, Ui.PRIMARY);
        gbc.gridy = row++;
        panel.add(completionLabel, gbc);

        progressBar = new JProgressBar(0, 100);
        progressBar.setValue(calculateCompletion());
        progressBar.setStringPainted(true);
        progressBar.setForeground(Ui.SUCCESS);
        gbc.gridy = row++;
        gbc.insets = new Insets(8, 8, 16, 8);
        panel.add(progressBar, gbc);

        gbc.insets = new Insets(4, 8, 4, 8);
        gbc.gridy = row++;
        panel.add(Ui.label("Contribution Amount:", Font.BOLD, 14, Ui.TEXT), gbc);

        contributionField = new JTextField();
        Ui.styleField(contributionField);
        gbc.gridy = row++;
        panel.add(contributionField, gbc);

        Ui.RoundedButton contributeButton = new Ui.RoundedButton("Contribute", Ui.PRIMARY);
        Ui.RoundedButton cancelButton = new Ui.RoundedButton("Cancel", Ui.NEUTRAL);
        JPanel buttons = Ui.buttonBar(cancelButton, contributeButton);

        gbc.gridy = row++;
        gbc.insets = new Insets(20, 8, 8, 8);
        panel.add(buttons, gbc);

        contributeButton.addActionListener(e -> makeContribution());
        cancelButton.addActionListener(e -> dispose());

        add(panel);
    }

    // ==========================================
    // Make Contribution (Person 6: CONTRIBUTE)
    // ==========================================

    private void makeContribution() {

        String input = contributionField.getText().trim();

        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a contribution amount.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double contribution = Double.parseDouble(input);

            if (contribution <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Contribution must be greater than zero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double remaining = itemPrice - amountRaised;

            if (contribution > remaining) {
                JOptionPane.showMessageDialog(this,
                        "Contribution cannot be greater than the remaining amount.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String response = ServerClient.send(
                    "CONTRIBUTE|" + contributorUserId + "|" + wishlistItemId + "|" + contribution
            );

            if (!ServerClient.isOk(response)) {
                JOptionPane.showMessageDialog(this,
                        "Contribution failed: " + ServerClient.dataOf(response),
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean completed = "true".equalsIgnoreCase(ServerClient.dataOf(response));

            amountRaised += contribution;
            updateDisplay();

            if (completed) {
                JOptionPane.showMessageDialog(this,
                        "The item is fully funded!", "Completed", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Contribution added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }

            contributionField.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // Update Display
    // ==========================================

    private void updateDisplay() {
        raisedLabel.setText(String.format("Amount Raised: $%.2f", amountRaised));
        remainingLabel.setText(String.format("Remaining: $%.2f", itemPrice - amountRaised));
        completionLabel.setText("Completion: " + calculateCompletion() + "%");
        progressBar.setValue(calculateCompletion());
    }

    private int calculateCompletion() {
        double percentage = (amountRaised / itemPrice) * 100;
        return (int) percentage;
    }

    public static void main(String[] args) {
        Ui.installLookAndFeel();
        SwingUtilities.invokeLater(() -> {
            ContributionGUI gui = new ContributionGUI();
            gui.setVisible(true);
        });
    }
}

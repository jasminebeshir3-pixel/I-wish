package org.example.person1;

import org.example.net.ServerClient;
import org.example.net.Session;
import org.example.ui.Ui;
import org.example.MainDashboard;

import javax.swing.*;
import java.awt.*;

/**
 * Person 1 — Authentication.
 *
 * One window, two tabs: Login and Register (spec point 1: Register/Sign-in).
 * On success, sets Session.currentUserId and opens MainDashboard, the same
 * way every other screen already expects to read the logged-in user from.
 */
public class AuthFrame extends JFrame {

    public AuthFrame() {
        super("i-Wish");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 480);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        JPanel root = new JPanel(new BorderLayout(0, 20));
        root.setBackground(Ui.BG);
        root.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JLabel title = Ui.label("i-Wish", Font.BOLD, 28, Ui.PRIMARY);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        JLabel subtitle = Ui.label("Make a wish. Make someone happy.", Font.PLAIN, 13, Ui.MUTED);
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);
        root.add(header, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Ui.font(Font.BOLD, 14));
        tabs.addTab("Sign In", buildLoginTab());
        tabs.addTab("Register", buildRegisterTab());
        root.add(tabs, BorderLayout.CENTER);

        setContentPane(root);
    }

    // =========================================================
    // Sign In
    // =========================================================

    private JPanel buildLoginTab() {

        JPanel panel = Ui.card(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridwidth = 2;

        JTextField username = new JTextField();
        JPasswordField password = new JPasswordField();
        Ui.styleField(username);
        Ui.styleField(password);

        gbc.gridy = 0;
        panel.add(Ui.label("Username", Font.PLAIN, 13, Ui.TEXT), gbc);
        gbc.gridy = 1;
        panel.add(username, gbc);

        gbc.gridy = 2;
        panel.add(Ui.label("Password", Font.PLAIN, 13, Ui.TEXT), gbc);
        gbc.gridy = 3;
        panel.add(password, gbc);

        Ui.RoundedButton loginBtn = new Ui.RoundedButton("Sign In", Ui.PRIMARY);
        gbc.gridy = 4;
        gbc.insets = new Insets(20, 8, 8, 8);
        panel.add(loginBtn, gbc);

        loginBtn.addActionListener(e -> {
            String u = username.getText().trim();
            String p = new String(password.getPassword());

            if (u.isEmpty() || p.isEmpty()) {
                showError("Please enter both username and password.");
                return;
            }

            String response = ServerClient.send("LOGIN|" + u + "|" + p);

            if (!ServerClient.isOk(response)) {
                showError(ServerClient.dataOf(response));
                return;
            }

            int userId = Integer.parseInt(ServerClient.dataOf(response));
            enterApp(userId, u);
        });

        return panel;
    }

    // =========================================================
    // Register
    // =========================================================

    private JPanel buildRegisterTab() {

        JPanel panel = Ui.card(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridwidth = 2;

        JTextField username = new JTextField();
        JTextField email = new JTextField();
        JPasswordField password = new JPasswordField();
        Ui.styleField(username);
        Ui.styleField(email);
        Ui.styleField(password);

        gbc.gridy = 0;
        panel.add(Ui.label("Username", Font.PLAIN, 13, Ui.TEXT), gbc);
        gbc.gridy = 1;
        panel.add(username, gbc);

        gbc.gridy = 2;
        panel.add(Ui.label("Email", Font.PLAIN, 13, Ui.TEXT), gbc);
        gbc.gridy = 3;
        panel.add(email, gbc);

        gbc.gridy = 4;
        panel.add(Ui.label("Password", Font.PLAIN, 13, Ui.TEXT), gbc);
        gbc.gridy = 5;
        panel.add(password, gbc);

        Ui.RoundedButton registerBtn = new Ui.RoundedButton("Create Account", Ui.SUCCESS);
        gbc.gridy = 6;
        gbc.insets = new Insets(20, 8, 8, 8);
        panel.add(registerBtn, gbc);

        registerBtn.addActionListener(e -> {
            String u = username.getText().trim();
            String em = email.getText().trim();
            String p = new String(password.getPassword());

            if (u.isEmpty() || em.isEmpty() || p.isEmpty()) {
                showError("Please fill in every field.");
                return;
            }

            String response = ServerClient.send("REGISTER|" + u + "|" + p + "|" + em);

            if (!ServerClient.isOk(response)) {
                showError(ServerClient.dataOf(response));
                return;
            }

            int userId = Integer.parseInt(ServerClient.dataOf(response));
            enterApp(userId, u);
        });

        return panel;
    }

    // =========================================================
    // Shared
    // =========================================================

    private void enterApp(int userId, String username) {
        Session.currentUserId = userId;
        dispose();
        SwingUtilities.invokeLater(() -> new MainDashboard(username).setVisible(true));
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // =========================================================
    // Main
    // =========================================================

    public static void main(String[] args) {
        Ui.installLookAndFeel();
        SwingUtilities.invokeLater(() -> new AuthFrame().setVisible(true));
    }
}

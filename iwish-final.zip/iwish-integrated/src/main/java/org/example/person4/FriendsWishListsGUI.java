package org.example.person4;

import org.example.net.ServerClient;
import org.example.net.Session;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class FriendsWishListsGUI extends JFrame {

    // Friends list
    private final DefaultListModel<String> friendsModel =
            new DefaultListModel<>();

    private final JList<String> friendsList =
            new JList<>(friendsModel);

    // Wishlist panel
    private final FriendWishlistPanel wishlistPanel;

    // Maps the displayed "username (ID: id)" string back to the friend's real id
    private final Map<String, Integer> friendIds = new HashMap<>();

    // The user currently browsing their friends (defaults to whoever is logged in)
    private final int currentUserId;


    public FriendsWishListsGUI() {
        this(Session.currentUserId);
    }

    public FriendsWishListsGUI(int currentUserId) {

        this.currentUserId = currentUserId;

        setTitle("Friends' Wish Lists");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        // -----------------------------
        // LEFT SIDE - Friends
        // -----------------------------

        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(Ui.BG);
        leftPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        leftPanel.setPreferredSize(new Dimension(300, 0));

        leftPanel.add(Ui.label("My Friends", Font.BOLD, 18, Ui.TEXT), BorderLayout.NORTH);

        friendsList.setFont(Ui.font(Font.PLAIN, 15));
        friendsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        friendsList.setBackground(Ui.CARD);
        friendsList.setSelectionBackground(Ui.SELECTION);
        friendsList.setSelectionForeground(Ui.TEXT);
        leftPanel.add(Ui.scroll(friendsList), BorderLayout.CENTER);

        Ui.RoundedButton refreshBtn = new Ui.RoundedButton("Refresh Friends", Ui.PRIMARY);
        JPanel refreshBar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        refreshBar.setOpaque(false);
        refreshBar.add(refreshBtn);
        leftPanel.add(refreshBar, BorderLayout.SOUTH);

        // -----------------------------
        // RIGHT SIDE - Wishlist
        // -----------------------------

        wishlistPanel = new FriendWishlistPanel("Select a friend");

        // -----------------------------
        // Split screen
        // -----------------------------

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT, leftPanel, wishlistPanel
        );
        splitPane.setDividerLocation(300);
        splitPane.setBorder(null);

        setContentPane(splitPane);

        // -----------------------------
        // Events
        // -----------------------------

        refreshBtn.addActionListener(e -> loadFriends());

        friendsList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selected = friendsList.getSelectedValue();
                if (selected != null && !selected.startsWith("No ")) {
                    loadFriendWishlist(selected);
                }
            }
        });

        loadFriends();
    }


    // =========================================================
    // Load Friends (Person 6: GET_FRIENDS)
    // =========================================================

    private void loadFriends() {

        friendsModel.clear();
        friendIds.clear();

        String response = ServerClient.send("GET_FRIENDS|" + currentUserId);

        if (!ServerClient.isOk(response)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not load friends: " + ServerClient.dataOf(response),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        for (String[] row : ServerClient.parseRows(ServerClient.dataOf(response))) {
            int friendId = Integer.parseInt(row[0]);
            String username = row[1];

            String display = username + " (ID: " + friendId + ")";
            friendsModel.addElement(display);
            friendIds.put(display, friendId);
        }

        if (friendsModel.isEmpty()) {
            friendsModel.addElement("No friends yet.");
        }
    }


    // =========================================================
    // Load Friend Wishlist (Person 6: GET_FRIEND_WISHLIST)
    // =========================================================

    private void loadFriendWishlist(String selectedFriend) {

        try {

            Integer friendId = friendIds.get(selectedFriend);
            if (friendId == null) return;

            String friendName = selectedFriend.substring(
                    0, selectedFriend.indexOf(" (ID:")
            ).trim();

            wishlistPanel.setFriendName(friendName);
            wishlistPanel.clearWishlist();

            // FIX (Person 6): protocol now also needs the caller's own id so the
            // server can check you're actually friends before returning the list -
            // see Protocol.GET_FRIEND_WISHLIST and ClientHandler for details.
            String response = ServerClient.send("GET_FRIEND_WISHLIST|" + currentUserId + "|" + friendId);

            if (!ServerClient.isOk(response)) {
                JOptionPane.showMessageDialog(
                        this,
                        "Could not load wishlist: " + ServerClient.dataOf(response),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            for (String[] row : ServerClient.parseRows(ServerClient.dataOf(response))) {
                String display =
                        "ID:" + row[0] +
                        " | " + row[1] +
                        " | Price:$" + row[2] +
                        " | Raised:$" + row[3] +
                        " | Done:" + row[4];

                wishlistPanel.addWishlistItem(display);
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading friend's wishlist: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    // =========================================================
    // Main
    // =========================================================

    public static void main(String[] args) {
        Ui.installLookAndFeel();
        SwingUtilities.invokeLater(() -> {
            FriendsWishListsGUI gui = new FriendsWishListsGUI();
            gui.setVisible(true);
        });
    }
}

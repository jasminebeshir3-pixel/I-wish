package org.example.person4;

import org.example.net.Session;
import org.example.person5.ContributionGUI;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;

public class WishlistItemDetailsGUI extends JFrame {

    public WishlistItemDetailsGUI(String rawItem) {

        setTitle("Item Details");
        setSize(480, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Ui.BG);

        JPanel panel = Ui.card(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        /*
         * Example (built by FriendsWishListsGUI from real server data):
         * ID:101 | PlayStation 5 | Price:$500 | Raised:$250 | Done:false
         */

        String[] parts = rawItem.split("\\|");

        String idText = parts.length > 0 ? parts[0].trim() : "ID:0";
        String nameText = parts.length > 1 ? parts[1].trim() : "N/A";
        String priceText = parts.length > 2 ? parts[2].trim() : "Price:$0";
        String raisedText = parts.length > 3 ? parts[3].trim() : "Raised:$0";
        String doneText = parts.length > 4 ? parts[4].trim() : "Done:false";

        final int wishlistItemId = parseIntSafe(idText.replace("ID:", ""));
        final double price = parseDoubleSafe(priceText.replace("Price:$", ""));
        final double raised = parseDoubleSafe(raisedText.replace("Raised:$", ""));
        final boolean completed = doneText.toLowerCase().contains("true");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.gridx = 0;
        gbc.gridwidth = 1;

        int row = 0;
        gbc.gridy = row++;
        panel.add(Ui.label(nameText, Font.BOLD, 22, Ui.TEXT), gbc);

        gbc.gridy = row++;
        panel.add(Ui.label(priceText, Font.PLAIN, 15, Ui.MUTED), gbc);

        gbc.gridy = row++;
        panel.add(Ui.label(raisedText, Font.PLAIN, 15, Ui.OK_TEXT), gbc);

        gbc.gridy = row++;
        panel.add(Ui.label(completed ? "Status: Completed" : "Status: In progress",
                Font.PLAIN, 15, completed ? Ui.SUCCESS : Ui.NEUTRAL), gbc);

        Ui.RoundedButton contributeBtn = new Ui.RoundedButton("Contribute", Ui.PRIMARY);
        Ui.RoundedButton closeBtn = new Ui.RoundedButton("Close", Ui.NEUTRAL);

        if (completed) {
            contributeBtn.setEnabled(false);
            contributeBtn.setToolTipText("This item is already fully funded.");
        }

        contributeBtn.addActionListener(e -> {
            ContributionGUI contributionGUI = new ContributionGUI(
                    wishlistItemId, nameText, price, raised, Session.currentUserId
            );
            contributionGUI.setVisible(true);
        });

        closeBtn.addActionListener(e -> dispose());

        JPanel buttons = Ui.buttonBar(closeBtn, contributeBtn);
        gbc.gridy = row++;
        gbc.insets = new Insets(20, 8, 8, 8);
        panel.add(buttons, gbc);

        add(panel);
        setVisible(true);
    }

    private int parseIntSafe(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private double parseDoubleSafe(String text) {
        try {
            return Double.parseDouble(text.trim());
        } catch (Exception e) {
            return 0.0;
        }
    }
}

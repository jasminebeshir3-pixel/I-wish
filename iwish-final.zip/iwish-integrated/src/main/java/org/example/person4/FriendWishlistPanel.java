package org.example.person4;

import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;

public class FriendWishlistPanel extends JPanel {

    private final DefaultListModel<String> wishlistModel = new DefaultListModel<>();
    private final JList<String> wishlistList = new JList<>(wishlistModel);
    private final JLabel titleLabel;

    public FriendWishlistPanel(String friendName) {

        setLayout(new BorderLayout(10, 10));
        setBackground(Ui.BG);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title
        titleLabel = Ui.label(friendName + "'s Wishlist", Font.BOLD, 20, Ui.TEXT);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        // Wishlist list
        wishlistList.setFont(Ui.font(Font.PLAIN, 15));
        wishlistList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        wishlistList.setBackground(Ui.CARD);
        wishlistList.setSelectionBackground(Ui.SELECTION);
        wishlistList.setSelectionForeground(Ui.TEXT);

        add(Ui.scroll(wishlistList), BorderLayout.CENTER);

        wishlistList.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent e) {

                        if (e.getClickCount() == 2) {

                            String selected = wishlistList.getSelectedValue();

                            if (selected != null && !selected.startsWith("No ")) {
                                new WishlistItemDetailsGUI(selected);
                            }
                        }
                    }
                }
        );
    }

    // Change friend's name
    public void setFriendName(String name) {
        titleLabel.setText(name + "'s Wishlist");
    }

    // Add item to wishlist
    public void addWishlistItem(String item) {
        wishlistModel.addElement(item);
    }

    // Clear wishlist
    public void clearWishlist() {
        wishlistModel.clear();
    }
}

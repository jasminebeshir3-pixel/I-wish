package org.example;

import org.example.net.Session;
import org.example.person1.AuthFrame;
import org.example.person2.FriendsPanel;
import org.example.person2.RealFriendsApi;
import org.example.person3.MyWishListFrame;
import org.example.person3.WishlistClient;
import org.example.person4.FriendsWishListsGUI;
import org.example.person5.NotificationsGUI;
import org.example.ui.Ui;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

/**
 * The app's home screen after Sign In / Register. One friendly place to
 * jump into every teammate's screen (spec point 10: friendly, welcoming GUI).
 */
public class MainDashboard extends JFrame {

    public MainDashboard(String username) {
        super("i-Wish — Welcome " + username);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(560, 520);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Ui.BG);

        JPanel root = new JPanel(new BorderLayout(0, 20));
        root.setBackground(Ui.BG);
        root.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        header.setOpaque(false);
        header.add(new JLabel(new Ui.AvatarIcon(56, username)));

        JPanel headerText = new JPanel(new GridLayout(2, 1));
        headerText.setOpaque(false);
        headerText.add(Ui.label("Hi, " + username + "!", Font.BOLD, 22, Ui.TEXT));
        headerText.add(Ui.label("What would you like to do?", Font.PLAIN, 13, Ui.MUTED));
        header.add(headerText);

        root.add(header, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 2, 16, 16));
        grid.setOpaque(false);

        grid.add(tile("My Wish List", Ui.PRIMARY, this::openMyWishList));
        grid.add(tile("My Friends", Ui.SUCCESS, this::openFriends));
        grid.add(tile("Friends' Wish Lists", new Color(0xE17055), this::openFriendsWishlists));
        grid.add(tile("Notifications", new Color(0x0984E3), this::openNotifications));

        root.add(grid, BorderLayout.CENTER);

        Ui.RoundedButton logoutBtn = new Ui.RoundedButton("Log Out", Ui.DANGER);
        JPanel south = new JPanel(new FlowLayout(FlowLayout.CENTER));
        south.setOpaque(false);
        south.add(logoutBtn);
        root.add(south, BorderLayout.SOUTH);

        logoutBtn.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new AuthFrame().setVisible(true));
        });

        setContentPane(root);
    }

    // =========================================================
    // Tile helper
    // =========================================================

    private JComponent tile(String text, Color color, Runnable action) {
        Ui.RoundedButton button = new Ui.RoundedButton(text, color);
        button.setPreferredSize(new Dimension(200, 100));
        button.setFont(Ui.font(Font.BOLD, 15));
        button.addActionListener(e -> action.run());
        return button;
    }

    // =========================================================
    // Screen launchers
    // =========================================================

    private void openMyWishList() {
        try {
            WishlistClient client = new WishlistClient("localhost", 5000);
            new MyWishListFrame(client, Session.currentUserId).setVisible(true);
        } catch (IOException ex) {
            showError("Could not connect to server: " + ex.getMessage());
        }
    }

    private void openFriends() {
        JFrame frame = new JFrame("My Friends");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(820, 640);
        frame.setLocationRelativeTo(null);

        FriendsPanel panel = new FriendsPanel(new RealFriendsApi(), Session.currentUserId);
        // FIX (Person 6): this used to just show a placeholder dialog naming
        // Person 4's screen instead of actually opening it. Now it opens the
        // real Friends' Wish Lists screen (same as the dashboard tile).
        panel.setOnViewWishList(friend -> new FriendsWishListsGUI(Session.currentUserId).setVisible(true));

        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    private void openFriendsWishlists() {
        new FriendsWishListsGUI(Session.currentUserId).setVisible(true);
    }

    private void openNotifications() {
        new NotificationsGUI(Session.currentUserId).setVisible(true);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}

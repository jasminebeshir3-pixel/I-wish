package org.example.net;

/**
 * Holds the id of the currently logged-in user.
 *
 * Person 1's login screen should set this right after a successful LOGIN
 * or REGISTER call, e.g.:
 *
 *   String response = ServerClient.send("LOGIN|" + username + "|" + password);
 *   if (ServerClient.isOk(response)) {
 *       Session.currentUserId = Integer.parseInt(ServerClient.dataOf(response));
 *   }
 *
 * Until the login screen is wired in, this defaults to user id 1
 * (the "ahmed" test account) so everyone else's screens can be tested
 * on their own.
 */
public class Session {
    public static int currentUserId = 1;
}

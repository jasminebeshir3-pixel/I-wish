package org.example.net;

import org.example.server.Protocol;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * Tiny helper used by every GUI (Person 1-5) to talk to Person 6's server.
 *
 * Usage:
 *   String response = ServerClient.send("LOGIN|ahmed|1234");
 *   if (ServerClient.isOk(response)) {
 *       String data = ServerClient.dataOf(response); // everything after "OK|"
 *       List<String[]> rows = ServerClient.parseRows(data); // for list responses
 *   }
 *
 * Opens a fresh connection per request - simple and good enough for this project.
 * Change HOST if the server runs on another machine on the network
 * (use that machine's IP address, e.g. "192.168.1.15").
 */
public class ServerClient {

    private static final String HOST = "localhost";
    private static final int PORT = 5000;

    /** Sends one request line and returns the raw response line (e.g. "OK|3" or "ERROR|message"). */
    public static String send(String request) {
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println(request);
            String response = in.readLine();
            return response != null ? response : Protocol.ERROR + "|No response from server";

        } catch (IOException e) {
            return Protocol.ERROR + "|Could not reach server: " + e.getMessage();
        }
    }

    /** True if the response starts with "OK". */
    public static boolean isOk(String response) {
        return response != null && response.startsWith(Protocol.OK);
    }

    /** Everything after "OK|" or "ERROR|" (empty string if there's no data). */
    public static String dataOf(String response) {
        if (response == null) return "";
        int sep = response.indexOf('|');
        return sep == -1 ? "" : response.substring(sep + 1);
    }

    /** Splits a list-style data payload into rows, then each row into fields. */
    public static List<String[]> parseRows(String data) {
        List<String[]> rows = new ArrayList<>();
        if (data == null || data.isEmpty()) return rows;

        String[] records = data.split(Protocol.RECORD_SEP);
        for (String record : records) {
            if (!record.isEmpty()) {
                rows.add(record.split(Protocol.FIELD_SEP));
            }
        }
        return rows;
    }
}

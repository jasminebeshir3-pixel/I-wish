package org.example.person5;

import javax.swing.*;
import java.awt.*;

public class NotificationsGUI extends JFrame {

    private final DefaultListModel<String> notificationModel =
            new DefaultListModel<>();

    private final JList<String> notificationList =
            new JList<>(notificationModel);

    public NotificationsGUI() {

        setTitle("Notifications");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        // Title
        JLabel titleLabel =
                new JLabel(
                        "Notifications",
                        SwingConstants.CENTER
                );

        titleLabel.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        mainPanel.add(
                titleLabel,
                BorderLayout.NORTH
        );

        // Notifications list
        notificationList.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );

        notificationList.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        mainPanel.add(
                new JScrollPane(notificationList),
                BorderLayout.CENTER
        );

        // Buttons panel
        JPanel buttonsPanel = new JPanel();

        JButton markReadButton =
                new JButton("Mark as Read");

        JButton refreshButton =
                new JButton("Refresh");

        JButton closeButton =
                new JButton("Close");

        buttonsPanel.add(markReadButton);
        buttonsPanel.add(refreshButton);
        buttonsPanel.add(closeButton);

        mainPanel.add(
                buttonsPanel,
                BorderLayout.SOUTH
        );

        // Mark as read
        markReadButton.addActionListener(
                e -> markSelectedAsRead()
        );

        // Refresh
        refreshButton.addActionListener(
                e -> loadNotifications()
        );

        // Close
        closeButton.addActionListener(
                e -> dispose()
        );

        add(mainPanel);

        // Load test notifications
        loadNotifications();
    }

    // ==========================================
    // Load Notifications
    // ==========================================

    private void loadNotifications() {

        notificationModel.clear();

        // TEST DATA
        notificationModel.addElement(
                "UNREAD | Your contribution was added successfully."
        );

        notificationModel.addElement(
                "UNREAD | PlayStation 5 is now fully funded."
        );

        notificationModel.addElement(
                "READ | Sara contributed to your wishlist."
        );

        notificationModel.addElement(
                "UNREAD | Your friend Ahmed added a new wishlist item."
        );
    }

    // ==========================================
    // Mark Selected Notification as Read
    // ==========================================

    private void markSelectedAsRead() {

        int selectedIndex =
                notificationList.getSelectedIndex();

        if (selectedIndex == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a notification first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String selected =
                notificationModel.getElementAt(
                        selectedIndex
                );

        if (selected.startsWith("READ")) {

            JOptionPane.showMessageDialog(
                    this,
                    "This notification is already marked as read.",
                    "Information",
                    JOptionPane.INFORMATION_MESSAGE
            );

            return;
        }

        // Change UNREAD to READ
        String updated =
                selected.replaceFirst(
                        "UNREAD",
                        "READ"
                );

        notificationModel.setElementAt(
                updated,
                selectedIndex
        );

        JOptionPane.showMessageDialog(
                this,
                "Notification marked as read.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // ==========================================
    // Main
    // ==========================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            NotificationsGUI gui =
                    new NotificationsGUI();

            gui.setVisible(true);
        });
    }
}

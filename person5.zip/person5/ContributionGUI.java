package org.example.person5;

import javax.swing.*;
import java.awt.*;

public class ContributionGUI extends JFrame {

    private JLabel itemNameLabel;
    private JLabel priceLabel;
    private JLabel raisedLabel;
    private JLabel remainingLabel;
    private JLabel completionLabel;

    private JTextField contributionField;

    // Test data
    private double itemPrice = 500.00;
    private double amountRaised = 250.00;

    public ContributionGUI() {

        setTitle("Make a Contribution");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main Panel
        JPanel panel = new JPanel();

        panel.setLayout(
                new BoxLayout(panel, BoxLayout.Y_AXIS)
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        25, 40, 25, 40
                )
        );

        // Title
        JLabel titleLabel =
                new JLabel("Make a Contribution");

        titleLabel.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        titleLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(titleLabel);

        panel.add(
                Box.createVerticalStrut(25)
        );

        // Item Name
        itemNameLabel =
                createLabel("Item: PlayStation 5");

        panel.add(itemNameLabel);

        panel.add(
                Box.createVerticalStrut(10)
        );

        // Item Price
        priceLabel =
                createLabel(
                        "Item Price: $" +
                        String.format("%.2f", itemPrice)
                );

        panel.add(priceLabel);

        panel.add(
                Box.createVerticalStrut(10)
        );

        // Amount Raised
        raisedLabel =
                createLabel(
                        "Amount Raised: $" +
                        String.format("%.2f", amountRaised)
                );

        panel.add(raisedLabel);

        panel.add(
                Box.createVerticalStrut(10)
        );

        // Remaining
        remainingLabel =
                createLabel(
                        "Remaining: $" +
                        String.format(
                                "%.2f",
                                itemPrice - amountRaised
                        )
                );

        panel.add(remainingLabel);

        panel.add(
                Box.createVerticalStrut(10)
        );

        // Completion
        completionLabel =
                createLabel(
                        "Completion: " +
                        calculateCompletion() +
                        "%"
                );

        panel.add(completionLabel);

        panel.add(
                Box.createVerticalStrut(25)
        );

        // Contribution Label
        JLabel amountLabel =
                new JLabel("Contribution Amount:");

        amountLabel.setFont(
                new Font("Arial", Font.BOLD, 15)
        );

        amountLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(amountLabel);

        panel.add(
                Box.createVerticalStrut(8)
        );

        // Contribution Text Field
        contributionField =
                new JTextField();

        contributionField.setMaximumSize(
                new Dimension(250, 35)
        );

        panel.add(contributionField);

        panel.add(
                Box.createVerticalStrut(25)
        );

        // Contribute Button
        JButton contributeButton =
                new JButton("Contribute");

        contributeButton.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        contributeButton.addActionListener(
                e -> makeContribution()
        );

        panel.add(contributeButton);

        panel.add(
                Box.createVerticalStrut(10)
        );

        // Cancel Button
        JButton cancelButton =
                new JButton("Cancel");

        cancelButton.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        cancelButton.addActionListener(
                e -> dispose()
        );

        panel.add(cancelButton);

        add(panel);
    }

    // ==========================================
    // Make Contribution
    // ==========================================

    private void makeContribution() {

        String input =
                contributionField.getText().trim();

        // Empty input
        if (input.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a contribution amount.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        try {

            double contribution =
                    Double.parseDouble(input);

            // Contribution must be positive
            if (contribution <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Contribution must be greater than zero.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            // Calculate remaining amount
            double remaining =
                    itemPrice - amountRaised;

            // Cannot contribute more than remaining
            if (contribution > remaining) {

                JOptionPane.showMessageDialog(
                        this,
                        "Contribution cannot be greater than the remaining amount.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            // Add contribution
            amountRaised += contribution;

            // Update screen
            updateDisplay();

            // Check completion
            if (amountRaised >= itemPrice) {

                JOptionPane.showMessageDialog(
                        this,
                        "The item is fully funded!",
                        "Completed",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Contribution added successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

            // Clear input
            contributionField.setText("");

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid number.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // Update Display
    // ==========================================

    private void updateDisplay() {

        raisedLabel.setText(
                "Amount Raised: $" +
                String.format("%.2f", amountRaised)
        );

        double remaining =
                itemPrice - amountRaised;

        remainingLabel.setText(
                "Remaining: $" +
                String.format("%.2f", remaining)
        );

        completionLabel.setText(
                "Completion: " +
                calculateCompletion() +
                "%"
        );
    }

    // ==========================================
    // Calculate Completion
    // ==========================================

    private int calculateCompletion() {

        double percentage =
                (amountRaised / itemPrice) * 100;

        return (int) percentage;
    }

    // ==========================================
    // Create Label
    // ==========================================

    private JLabel createLabel(String text) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );

        label.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        return label;
    }

    // ==========================================
    // Main
    // ==========================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            ContributionGUI gui =
                    new ContributionGUI();

            gui.setVisible(true);
        });
    }
}

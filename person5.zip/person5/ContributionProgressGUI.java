package org.example.person5;

import javax.swing.*;
import java.awt.*;

public class ContributionProgressGUI extends JFrame {

    private double itemPrice = 500.00;
    private double amountRaised = 250.00;

    private JLabel raisedLabel;
    private JLabel remainingLabel;
    private JLabel percentageLabel;

    private JProgressBar progressBar;

    public ContributionProgressGUI() {

        setTitle("Contribution Progress");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();

        panel.setLayout(
                new BoxLayout(
                        panel,
                        BoxLayout.Y_AXIS
                )
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        25, 30, 25, 30
                )
        );

        JLabel title =
                new JLabel("Gift Contribution Progress");

        title.setFont(
                new Font("Arial", Font.BOLD, 23)
        );

        title.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(title);

        panel.add(
                Box.createVerticalStrut(25)
        );

        raisedLabel =
                createLabel("");

        remainingLabel =
                createLabel("");

        percentageLabel =
                createLabel("");

        panel.add(raisedLabel);

        panel.add(
                Box.createVerticalStrut(10)
        );

        panel.add(remainingLabel);

        panel.add(
                Box.createVerticalStrut(10)
        );

        panel.add(percentageLabel);

        panel.add(
                Box.createVerticalStrut(20)
        );

        progressBar =
                new JProgressBar(0, 100);

        progressBar.setStringPainted(true);

        progressBar.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(progressBar);

        panel.add(
                Box.createVerticalStrut(25)
        );

        JButton closeButton =
                new JButton("Close");

        closeButton.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        closeButton.addActionListener(
                e -> dispose()
        );

        panel.add(closeButton);

        add(panel);

        updateProgress();
    }

    private void updateProgress() {

        double remaining =
                itemPrice - amountRaised;

        int percentage =
                (int) ((amountRaised / itemPrice) * 100);

        raisedLabel.setText(
                "Amount Raised: $" +
                String.format("%.2f", amountRaised)
        );

        remainingLabel.setText(
                "Remaining: $" +
                String.format("%.2f", remaining)
        );

        percentageLabel.setText(
                "Completion: " +
                percentage +
                "%"
        );

        progressBar.setValue(percentage);
    }

    private JLabel createLabel(String text) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );

        label.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        return label;
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            ContributionProgressGUI gui =
                    new ContributionProgressGUI();

            gui.setVisible(true);
        });
    }
}
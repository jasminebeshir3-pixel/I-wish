package org.example.person5;

import javax.swing.*;
import java.awt.*;

public class ContributionsGUI extends JFrame {

    private final DefaultListModel<String> itemModel =
            new DefaultListModel<>();

    private final JList<String> itemList =
            new JList<>(itemModel);

    public ContributionsGUI() {

        setTitle("Friends' Wishlist Items");
        setSize(650, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel =
                new JPanel(new BorderLayout(10, 10));

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        JLabel title =
                new JLabel(
                        "Select Items to Contribute",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        mainPanel.add(title, BorderLayout.NORTH);

        // Test items
        loadItems();

        itemList.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );

        // Allow selecting more than one item
        itemList.setSelectionMode(
                ListSelectionModel.MULTIPLE_INTERVAL_SELECTION
        );

        mainPanel.add(
                new JScrollPane(itemList),
                BorderLayout.CENTER
        );

        JPanel bottomPanel = new JPanel();

        JButton contributeButton =
                new JButton("Contribute");

        JButton closeButton =
                new JButton("Close");

        bottomPanel.add(contributeButton);
        bottomPanel.add(closeButton);

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        contributeButton.addActionListener(
                e -> openContribution()
        );

        closeButton.addActionListener(
                e -> dispose()
        );

        add(mainPanel);
    }

    private void loadItems() {

        itemModel.clear();

        itemModel.addElement(
                "ID:101 | PlayStation 5 | Price:$500 | Raised:$250"
        );

        itemModel.addElement(
                "ID:102 | Headphones | Price:$100 | Raised:$40"
        );

        itemModel.addElement(
                "ID:103 | Smart Watch | Price:$200 | Raised:$50"
        );
    }

    private void openContribution() {

        if (itemList.getSelectedIndices().length == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select at least one item.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        JOptionPane.showMessageDialog(
                this,
                "Selected items are ready for contribution."
        );

        new ContributionGUI().setVisible(true);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            ContributionsGUI gui =
                    new ContributionsGUI();

            gui.setVisible(true);
        });
    }
}